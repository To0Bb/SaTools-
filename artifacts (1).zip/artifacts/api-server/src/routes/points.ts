import { Router, type IRouter } from "express";
import { eq, sql, desc } from "drizzle-orm";
import { db, usersTable, pointTransactionsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/points/balance", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "المستخدم غير موجود" }); return; }

  // Total earned
  const earned = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)::int` })
    .from(pointTransactionsTable)
    .where(eq(pointTransactionsTable.toUserId, userId));

  // Total spent
  const spent = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)::int` })
    .from(pointTransactionsTable)
    .where(eq(pointTransactionsTable.fromUserId, userId));

  res.json({
    balance: user.points,
    totalEarned: earned[0]?.total ?? 0,
    totalSpent: spent[0]?.total ?? 0,
  });
});

router.get("/points/history", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }

  const fromAlias = db.$with("from_user").as(db.select({ id: usersTable.id, username: usersTable.username }).from(usersTable));
  const toAlias = db.$with("to_user").as(db.select({ id: usersTable.id, username: usersTable.username }).from(usersTable));

  // Simpler approach: join manually
  const rows = await db.execute(sql`
    SELECT pt.id, pt.from_user_id as "fromUserId", pt.to_user_id as "toUserId",
           pt.amount, pt.type, pt.note, pt.created_at as "createdAt",
           fu.username as "fromUsername", tu.username as "toUsername"
    FROM point_transactions pt
    LEFT JOIN users fu ON fu.id = pt.from_user_id
    LEFT JOIN users tu ON tu.id = pt.to_user_id
    WHERE pt.from_user_id = ${userId} OR pt.to_user_id = ${userId}
    ORDER BY pt.created_at DESC
    LIMIT 50
  `);

  res.json(rows.rows);
});

router.post("/points/transfer", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const [admin] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (admin?.role !== "admin") { res.status(403).json({ error: "محظور - للمدير فقط" }); return; }

  const { toUserId, amount, note } = req.body;
  if (!toUserId || !amount || amount <= 0) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }

  const [target] = await db.select().from(usersTable).where(eq(usersTable.id, parseInt(toUserId, 10)));
  if (!target) { res.status(404).json({ error: "المستخدم غير موجود" }); return; }

  // Add points to target
  await db.update(usersTable).set({ points: sql`points + ${amount}` }).where(eq(usersTable.id, target.id));

  // Record transaction
  await db.insert(pointTransactionsTable).values({
    fromUserId: userId,
    toUserId: target.id,
    amount: parseInt(amount, 10),
    type: "transferred",
    note: note ?? `تحويل من الأدمن`,
  });

  const [updatedAdmin] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  res.json({ balance: updatedAdmin.points, totalEarned: 0, totalSpent: 0 });
});

router.post("/points/donate", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }

  const { toUsername, amount } = req.body;
  if (!toUsername || !amount || amount <= 0) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }

  const [donor] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!donor) { res.status(404).json({ error: "المستخدم غير موجود" }); return; }

  const donateAmount = parseInt(amount, 10);
  if (donor.points < donateAmount) { res.status(400).json({ error: "رصيدك غير كافٍ" }); return; }

  const [recipient] = await db.select().from(usersTable).where(eq(usersTable.username, toUsername));
  if (!recipient) { res.status(404).json({ error: `المستخدم @${toUsername} غير موجود` }); return; }
  if (recipient.id === userId) { res.status(400).json({ error: "لا يمكنك التبرع لنفسك" }); return; }

  // Deduct from donor
  await db.update(usersTable).set({ points: sql`points - ${donateAmount}` }).where(eq(usersTable.id, userId));
  // Add to recipient
  await db.update(usersTable).set({ points: sql`points + ${donateAmount}` }).where(eq(usersTable.id, recipient.id));

  // Record transactions
  await db.insert(pointTransactionsTable).values([
    { fromUserId: userId, toUserId: recipient.id, amount: donateAmount, type: "donated", note: `تبرع لـ @${toUsername}` },
  ]);

  const [updatedDonor] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  res.json({ balance: updatedDonor.points, totalEarned: 0, totalSpent: donateAmount });
});

export default router;
