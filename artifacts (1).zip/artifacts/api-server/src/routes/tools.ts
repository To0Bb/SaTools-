import { Router, type IRouter } from "express";
import { eq, ilike, and } from "drizzle-orm";
import { db, toolsTable, categoriesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/tools", async (req, res): Promise<void> => {
  const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string, 10) : undefined;
  const search = req.query.search as string | undefined;

  const rows = await db
    .select({
      id: toolsTable.id,
      name: toolsTable.name,
      description: toolsTable.description,
      icon: toolsTable.icon,
      url: toolsTable.url,
      categoryId: toolsTable.categoryId,
      categoryName: categoriesTable.name,
      isActive: toolsTable.isActive,
      isPremium: toolsTable.isPremium,
      createdAt: toolsTable.createdAt,
    })
    .from(toolsTable)
    .leftJoin(categoriesTable, eq(toolsTable.categoryId, categoriesTable.id))
    .where(
      and(
        categoryId ? eq(toolsTable.categoryId, categoryId) : undefined,
        search ? ilike(toolsTable.name, `%${search}%`) : undefined,
      ),
    )
    .orderBy(toolsTable.id);

  res.json(rows);
});

router.post("/tools", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const { name, description, icon, url, categoryId, isActive, isPremium } = req.body;
  if (!name || !description || !icon || !categoryId) {
    res.status(400).json({ error: "الحقول المطلوبة ناقصة" });
    return;
  }
  const [tool] = await db.insert(toolsTable).values({
    name, description, icon, url, categoryId: parseInt(categoryId, 10),
    isActive: isActive !== undefined ? isActive : true,
    isPremium: isPremium !== undefined ? isPremium : false,
  }).returning();
  const [row] = await db.select({
    id: toolsTable.id,
    name: toolsTable.name,
    description: toolsTable.description,
    icon: toolsTable.icon,
    url: toolsTable.url,
    categoryId: toolsTable.categoryId,
    categoryName: categoriesTable.name,
    isActive: toolsTable.isActive,
    isPremium: toolsTable.isPremium,
    createdAt: toolsTable.createdAt,
  }).from(toolsTable).leftJoin(categoriesTable, eq(toolsTable.categoryId, categoriesTable.id)).where(eq(toolsTable.id, tool.id));
  res.status(201).json(row);
});

router.get("/tools/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [row] = await db.select({
    id: toolsTable.id,
    name: toolsTable.name,
    description: toolsTable.description,
    icon: toolsTable.icon,
    url: toolsTable.url,
    categoryId: toolsTable.categoryId,
    categoryName: categoriesTable.name,
    isActive: toolsTable.isActive,
    isPremium: toolsTable.isPremium,
    createdAt: toolsTable.createdAt,
  }).from(toolsTable).leftJoin(categoriesTable, eq(toolsTable.categoryId, categoriesTable.id)).where(eq(toolsTable.id, id));
  if (!row) { res.status(404).json({ error: "الأداة غير موجودة" }); return; }
  res.json(row);
});

router.patch("/tools/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { name, description, icon, url, categoryId, isActive, isPremium } = req.body;
  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (description !== undefined) updates.description = description;
  if (icon !== undefined) updates.icon = icon;
  if (url !== undefined) updates.url = url;
  if (categoryId !== undefined) updates.categoryId = parseInt(categoryId, 10);
  if (isActive !== undefined) updates.isActive = isActive;
  if (isPremium !== undefined) updates.isPremium = isPremium;
  await db.update(toolsTable).set(updates).where(eq(toolsTable.id, id));
  const [row] = await db.select({
    id: toolsTable.id,
    name: toolsTable.name,
    description: toolsTable.description,
    icon: toolsTable.icon,
    url: toolsTable.url,
    categoryId: toolsTable.categoryId,
    categoryName: categoriesTable.name,
    isActive: toolsTable.isActive,
    isPremium: toolsTable.isPremium,
    createdAt: toolsTable.createdAt,
  }).from(toolsTable).leftJoin(categoriesTable, eq(toolsTable.categoryId, categoriesTable.id)).where(eq(toolsTable.id, id));
  if (!row) { res.status(404).json({ error: "الأداة غير موجودة" }); return; }
  res.json(row);
});

router.delete("/tools/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  await db.delete(toolsTable).where(eq(toolsTable.id, id));
  res.sendStatus(204);
});

export default router;
