import { Router, type IRouter } from "express";
import { eq, sql, count, gt } from "drizzle-orm";
import { db, usersTable, toolsTable, chatMessagesTable, siteStatsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/stats", async (req, res): Promise<void> => {
  // Increment visitor counter
  await db
    .insert(siteStatsTable)
    .values({ key: "total_visitors", value: 1 })
    .onConflictDoUpdate({
      target: siteStatsTable.key,
      set: { value: sql`site_stats.value + 1` },
    });

  // Fetch stats in parallel
  const [visitorRow] = await db
    .select()
    .from(siteStatsTable)
    .where(eq(siteStatsTable.key, "total_visitors"));

  const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);

  const [membersRow] = await db.select({ count: count() }).from(usersTable);
  const [activeRow] = await db
    .select({ count: count() })
    .from(usersTable)
    .where(gt(usersTable.lastSeen, tenMinutesAgo));
  const [toolsRow] = await db.select({ count: count() }).from(toolsTable);
  const [messagesRow] = await db.select({ count: count() }).from(chatMessagesTable);

  res.json({
    totalVisitors: Number(visitorRow?.value ?? 0),
    activeUsers: activeRow?.count ?? 0,
    totalMembers: membersRow?.count ?? 0,
    totalTools: toolsRow?.count ?? 0,
    totalMessages: messagesRow?.count ?? 0,
  });
});

export default router;
