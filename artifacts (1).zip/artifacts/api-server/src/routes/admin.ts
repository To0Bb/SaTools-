import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, toolsTable, categoriesTable, ticketsTable, chatMessagesTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/admin/stats", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || user.role !== "admin") { res.status(403).json({ error: "محظور" }); return; }

  const [{ count: totalUsers }] = await db.select({ count: sql<number>`count(*)::int` }).from(usersTable);
  const [{ count: totalTools }] = await db.select({ count: sql<number>`count(*)::int` }).from(toolsTable);
  const [{ count: totalCategories }] = await db.select({ count: sql<number>`count(*)::int` }).from(categoriesTable);
  const [{ count: totalTickets }] = await db.select({ count: sql<number>`count(*)::int` }).from(ticketsTable);
  const [{ count: openTickets }] = await db.select({ count: sql<number>`count(*)::int` }).from(ticketsTable).where(eq(ticketsTable.status, "open"));
  const [{ count: totalMessages }] = await db.select({ count: sql<number>`count(*)::int` }).from(chatMessagesTable);

  res.json({ totalUsers, totalTools, totalCategories, totalTickets, openTickets, totalMessages });
});

router.get("/admin/users", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || user.role !== "admin") { res.status(403).json({ error: "محظور" }); return; }
  const users = await db.select({
    id: usersTable.id,
    username: usersTable.username,
    displayName: usersTable.displayName,
    role: usersTable.role,
    createdAt: usersTable.createdAt,
  }).from(usersTable).orderBy(usersTable.id);
  res.json(users);
});

export default router;
