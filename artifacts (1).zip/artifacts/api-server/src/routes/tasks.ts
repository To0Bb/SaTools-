import { Router, type IRouter } from "express";
import { eq, and, gte, sql } from "drizzle-orm";
import { db, tasksTable, userTasksTable, usersTable, pointTransactionsTable } from "@workspace/db";

const router: IRouter = Router();

function todayStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

async function getTasksWithStatus(userId?: number) {
  const tasks = await db.select().from(tasksTable).where(eq(tasksTable.isActive, true)).orderBy(tasksTable.id);
  if (!userId) return tasks.map(t => ({ ...t, completedToday: false }));

  const completedToday = await db
    .select({ taskId: userTasksTable.taskId })
    .from(userTasksTable)
    .where(and(eq(userTasksTable.userId, userId), gte(userTasksTable.completedAt, todayStart())));

  const completedIds = new Set(completedToday.map(c => c.taskId));
  return tasks.map(t => ({ ...t, completedToday: completedIds.has(t.id) }));
}

router.get("/tasks", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  const tasks = await getTasksWithStatus(userId ?? undefined);
  res.json(tasks);
});

router.post("/tasks", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (user?.role !== "admin") { res.status(403).json({ error: "محظور" }); return; }
  const { title, description, pointsReward, taskType, icon, isActive } = req.body;
  if (!title || !description) { res.status(400).json({ error: "الحقول المطلوبة ناقصة" }); return; }
  const [task] = await db.insert(tasksTable).values({
    title, description, pointsReward: pointsReward ?? 10, taskType: taskType ?? "daily",
    icon: icon ?? "Star", isActive: isActive !== undefined ? isActive : true,
  }).returning();
  res.status(201).json({ ...task, completedToday: false });
});

router.patch("/tasks/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (user?.role !== "admin") { res.status(403).json({ error: "محظور" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { title, description, pointsReward, taskType, icon, isActive } = req.body;
  const updates: Record<string, unknown> = {};
  if (title !== undefined) updates.title = title;
  if (description !== undefined) updates.description = description;
  if (pointsReward !== undefined) updates.pointsReward = pointsReward;
  if (taskType !== undefined) updates.taskType = taskType;
  if (icon !== undefined) updates.icon = icon;
  if (isActive !== undefined) updates.isActive = isActive;
  const [task] = await db.update(tasksTable).set(updates).where(eq(tasksTable.id, id)).returning();
  if (!task) { res.status(404).json({ error: "المهمة غير موجودة" }); return; }
  res.json({ ...task, completedToday: false });
});

router.delete("/tasks/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (user?.role !== "admin") { res.status(403).json({ error: "محظور" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  await db.delete(userTasksTable).where(eq(userTasksTable.taskId, id));
  await db.delete(tasksTable).where(eq(tasksTable.id, id));
  res.sendStatus(204);
});

router.post("/tasks/:id/complete", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const taskId = parseInt(raw, 10);
  const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, taskId));
  if (!task || !task.isActive) { res.status(404).json({ error: "المهمة غير موجودة" }); return; }

  // Check already completed today (for daily tasks)
  if (task.taskType === "daily") {
    const [existing] = await db.select().from(userTasksTable).where(
      and(eq(userTasksTable.userId, userId), eq(userTasksTable.taskId, taskId), gte(userTasksTable.completedAt, todayStart()))
    );
    if (existing) { res.status(400).json({ error: "لقد أكملت هذه المهمة اليوم بالفعل" }); return; }
  } else {
    // Once tasks: check if ever completed
    const [existing] = await db.select().from(userTasksTable).where(
      and(eq(userTasksTable.userId, userId), eq(userTasksTable.taskId, taskId))
    );
    if (existing) { res.status(400).json({ error: "لقد أكملت هذه المهمة مسبقاً" }); return; }
  }

  // Record completion
  await db.insert(userTasksTable).values({ userId, taskId });

  // Add points to user
  await db.update(usersTable).set({ points: sql`points + ${task.pointsReward}` }).where(eq(usersTable.id, userId));

  // Record transaction
  await db.insert(pointTransactionsTable).values({
    toUserId: userId,
    amount: task.pointsReward,
    type: "earned",
    note: `إتمام مهمة: ${task.title}`,
  });

  const [updatedUser] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  res.json({
    pointsEarned: task.pointsReward,
    newBalance: updatedUser.points,
    message: `أحسنت! حصلت على ${task.pointsReward} نقطة`,
  });
});

export default router;
