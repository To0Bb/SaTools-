import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import categoriesRouter from "./categories";
import toolsRouter from "./tools";
import chatRouter from "./chat";
import supportRouter from "./support";
import plansRouter from "./plans";
import phoneServicesRouter from "./phone_services";
import publicNumbersRouter from "./public_numbers";
import statsRouter from "./stats";
import tasksRouter from "./tasks";
import pointsRouter from "./points";
import toolExecuteRouter from "./tool_execute";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(categoriesRouter);
router.use(toolsRouter);
router.use(chatRouter);
router.use(supportRouter);
router.use(plansRouter);
router.use(phoneServicesRouter);
router.use(publicNumbersRouter);
router.use(statsRouter);
router.use(tasksRouter);
router.use(pointsRouter);
router.use(toolExecuteRouter);
router.use(adminRouter);

export default router;
