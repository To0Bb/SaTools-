import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, ticketsTable, ticketRepliesTable, usersTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/support", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const user = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  const isAdmin = user[0]?.role === "admin";

  const rows = await db
    .select({
      id: ticketsTable.id,
      subject: ticketsTable.subject,
      message: ticketsTable.message,
      status: ticketsTable.status,
      userId: ticketsTable.userId,
      username: usersTable.username,
      displayName: usersTable.displayName,
      createdAt: ticketsTable.createdAt,
      updatedAt: ticketsTable.updatedAt,
    })
    .from(ticketsTable)
    .leftJoin(usersTable, eq(ticketsTable.userId, usersTable.id))
    .where(isAdmin ? undefined : eq(ticketsTable.userId, userId))
    .orderBy(desc(ticketsTable.createdAt));

  res.json(rows);
});

router.post("/support", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const { subject, message } = req.body;
  if (!subject || !message) { res.status(400).json({ error: "الموضوع والرسالة مطلوبان" }); return; }
  const [ticket] = await db.insert(ticketsTable).values({ subject, message, userId, status: "open" }).returning();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  res.status(201).json({
    id: ticket.id,
    subject: ticket.subject,
    message: ticket.message,
    status: ticket.status,
    userId: ticket.userId,
    username: user?.username ?? "",
    displayName: user?.displayName ?? "",
    createdAt: ticket.createdAt,
    updatedAt: ticket.updatedAt,
  });
});

router.get("/support/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [row] = await db
    .select({
      id: ticketsTable.id,
      subject: ticketsTable.subject,
      message: ticketsTable.message,
      status: ticketsTable.status,
      userId: ticketsTable.userId,
      username: usersTable.username,
      displayName: usersTable.displayName,
      createdAt: ticketsTable.createdAt,
      updatedAt: ticketsTable.updatedAt,
    })
    .from(ticketsTable)
    .leftJoin(usersTable, eq(ticketsTable.userId, usersTable.id))
    .where(eq(ticketsTable.id, id));
  if (!row) { res.status(404).json({ error: "التذكرة غير موجودة" }); return; }
  res.json(row);
});

router.patch("/support/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { status } = req.body;
  if (!status) { res.status(400).json({ error: "الحالة مطلوبة" }); return; }
  const [ticket] = await db.update(ticketsTable).set({ status }).where(eq(ticketsTable.id, id)).returning();
  if (!ticket) { res.status(404).json({ error: "التذكرة غير موجودة" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, ticket.userId));
  res.json({
    id: ticket.id,
    subject: ticket.subject,
    message: ticket.message,
    status: ticket.status,
    userId: ticket.userId,
    username: user?.username ?? "",
    displayName: user?.displayName ?? "",
    createdAt: ticket.createdAt,
    updatedAt: ticket.updatedAt,
  });
});

router.get("/support/:id/replies", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const rows = await db
    .select({
      id: ticketRepliesTable.id,
      ticketId: ticketRepliesTable.ticketId,
      content: ticketRepliesTable.content,
      userId: ticketRepliesTable.userId,
      username: usersTable.username,
      displayName: usersTable.displayName,
      isAdmin: ticketRepliesTable.isAdmin,
      createdAt: ticketRepliesTable.createdAt,
    })
    .from(ticketRepliesTable)
    .leftJoin(usersTable, eq(ticketRepliesTable.userId, usersTable.id))
    .where(eq(ticketRepliesTable.ticketId, id))
    .orderBy(ticketRepliesTable.createdAt);
  res.json(rows);
});

router.post("/support/:id/replies", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const ticketId = parseInt(raw, 10);
  const { content } = req.body;
  if (!content) { res.status(400).json({ error: "المحتوى مطلوب" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  const isAdmin = user?.role === "admin";
  const [reply] = await db.insert(ticketRepliesTable).values({ ticketId, content, userId, isAdmin }).returning();
  res.status(201).json({
    id: reply.id,
    ticketId: reply.ticketId,
    content: reply.content,
    userId: reply.userId,
    username: user?.username ?? "",
    displayName: user?.displayName ?? "",
    isAdmin: reply.isAdmin,
    createdAt: reply.createdAt,
  });
});

export default router;
