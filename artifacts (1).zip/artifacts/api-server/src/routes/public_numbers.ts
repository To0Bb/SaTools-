import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, publicNumbersTable, numberMessagesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/public-numbers", async (req, res): Promise<void> => {
  const numbers = await db.select().from(publicNumbersTable).orderBy(publicNumbersTable.id);
  res.json(numbers);
});

router.get("/public-numbers/:id/messages", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const messages = await db
    .select()
    .from(numberMessagesTable)
    .where(eq(numberMessagesTable.numberId, id))
    .orderBy(numberMessagesTable.receivedAt);
  res.json(messages);
});

export default router;
