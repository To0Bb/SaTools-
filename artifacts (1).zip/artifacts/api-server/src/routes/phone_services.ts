import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, phoneServicesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/phone-services", async (req, res): Promise<void> => {
  const services = await db.select().from(phoneServicesTable).where(eq(phoneServicesTable.isActive, true)).orderBy(phoneServicesTable.id);
  res.json(services);
});

export default router;
