import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, plansTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/plans", async (req, res): Promise<void> => {
  const plans = await db.select().from(plansTable).where(eq(plansTable.isActive, true)).orderBy(plansTable.id);
  res.json(plans.map(p => ({
    ...p,
    price: parseFloat(p.price),
  })));
});

router.post("/plans", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const { name, price, period, features, isActive, isPopular } = req.body;
  if (!name || price === undefined || !period || !features) {
    res.status(400).json({ error: "الحقول المطلوبة ناقصة" });
    return;
  }
  const [plan] = await db.insert(plansTable).values({
    name, price: String(price), period, features,
    isActive: isActive !== undefined ? isActive : true,
    isPopular: isPopular !== undefined ? isPopular : false,
  }).returning();
  res.status(201).json({ ...plan, price: parseFloat(plan.price) });
});

router.patch("/plans/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { name, price, period, features, isActive, isPopular } = req.body;
  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (price !== undefined) updates.price = String(price);
  if (period !== undefined) updates.period = period;
  if (features !== undefined) updates.features = features;
  if (isActive !== undefined) updates.isActive = isActive;
  if (isPopular !== undefined) updates.isPopular = isPopular;
  const [plan] = await db.update(plansTable).set(updates).where(eq(plansTable.id, id)).returning();
  if (!plan) { res.status(404).json({ error: "الخطة غير موجودة" }); return; }
  res.json({ ...plan, price: parseFloat(plan.price) });
});

router.delete("/plans/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  await db.delete(plansTable).where(eq(plansTable.id, id));
  res.sendStatus(204);
});

export default router;
