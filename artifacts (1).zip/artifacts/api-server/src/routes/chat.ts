import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, chatMessagesTable, usersTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/chat", async (req, res): Promise<void> => {
  const rows = await db
    .select({
      id: chatMessagesTable.id,
      content: chatMessagesTable.content,
      userId: chatMessagesTable.userId,
      username: usersTable.username,
      displayName: usersTable.displayName,
      createdAt: chatMessagesTable.createdAt,
    })
    .from(chatMessagesTable)
    .leftJoin(usersTable, eq(chatMessagesTable.userId, usersTable.id))
    .orderBy(chatMessagesTable.createdAt)
    .limit(100);
  res.json(rows);
});

router.post("/chat", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "يجب تسجيل الدخول أولاً" }); return; }
  const { content } = req.body;
  if (!content || content.length === 0) { res.status(400).json({ error: "المحتوى مطلوب" }); return; }
  if (content.length > 500) { res.status(400).json({ error: "الرسالة طويلة جداً" }); return; }
  const [msg] = await db.insert(chatMessagesTable).values({ content, userId }).returning();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  res.status(201).json({
    id: msg.id,
    content: msg.content,
    userId: msg.userId,
    username: user?.username ?? "",
    displayName: user?.displayName ?? "",
    createdAt: msg.createdAt,
  });
});

router.delete("/chat/:id", async (req, res): Promise<void> => {
  const userId = (req.session as any)?.userId;
  if (!userId) { res.status(401).json({ error: "غير مصرح" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  await db.delete(chatMessagesTable).where(eq(chatMessagesTable.id, id));
  res.sendStatus(204);
});

export default router;
