import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import * as dns from "dns/promises";
import * as crypto from "crypto";
import { db, usersTable, toolsTable, pointTransactionsTable } from "@workspace/db";

const router: IRouter = Router();

async function executeToolLogic(slug: string, input: Record<string, string>): Promise<{ success: boolean; data?: Record<string, unknown>; error?: string }> {
  try {
    const cleanSlug = slug.replace(/^\/tools\//, "");

    // IP Lookup
    if (cleanSlug === "ip-lookup" || cleanSlug === "ip") {
      const ip = input.ip?.trim() || "";
      const url = ip ? `http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query` : "http://ip-api.com/json/?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query";
      const resp = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const data = await resp.json() as Record<string, unknown>;
      if (data.status === "fail") return { success: false, error: `فشل البحث: ${data.message}` };
      return { success: true, data: {
        "IP": data.query, "الدولة": `${data.country} (${data.countryCode})`, "المنطقة": data.regionName,
        "المدينة": data.city, "الرمز البريدي": data.zip, "خط العرض": data.lat, "خط الطول": data.lon,
        "المنطقة الزمنية": data.timezone, "مزود الخدمة": data.isp, "المؤسسة": data.org,
      }};
    }

    // DNS Lookup
    if (cleanSlug === "dns-lookup") {
      const domain = input.domain?.trim();
      const type = (input.type || "A").toUpperCase();
      if (!domain) return { success: false, error: "أدخل اسم النطاق" };
      let records: unknown[] = [];
      try {
        if (type === "A") records = await dns.resolve4(domain);
        else if (type === "AAAA") records = await dns.resolve6(domain);
        else if (type === "MX") records = await dns.resolveMx(domain);
        else if (type === "TXT") records = await dns.resolveTxt(domain);
        else if (type === "NS") records = await dns.resolveNs(domain);
        else if (type === "CNAME") records = await dns.resolveCname(domain);
        else records = await dns.resolve(domain, type as dns.RecordWithTtl["type"]);
      } catch (e: any) {
        return { success: false, error: `لم يتم العثور على سجلات ${type} للنطاق ${domain}` };
      }
      return { success: true, data: { "النطاق": domain, "نوع السجل": type, "النتائج": records } };
    }

    // Ping / Speed Test
    if (cleanSlug === "ping" || cleanSlug === "speed-test") {
      const host = input.host?.trim() || input.url?.trim();
      if (!host) return { success: false, error: "أدخل عنوان الخادم أو URL" };
      const url = host.startsWith("http") ? host : `https://${host}`;
      const times: number[] = [];
      for (let i = 0; i < 3; i++) {
        const start = Date.now();
        try {
          await fetch(url, { method: "HEAD", signal: AbortSignal.timeout(5000) });
          times.push(Date.now() - start);
        } catch {
          times.push(-1);
        }
      }
      const validTimes = times.filter(t => t >= 0);
      const avg = validTimes.length ? Math.round(validTimes.reduce((a, b) => a + b, 0) / validTimes.length) : null;
      return { success: true, data: {
        "الهدف": url,
        "محاولة 1": times[0] >= 0 ? `${times[0]}ms` : "فشل",
        "محاولة 2": times[1] >= 0 ? `${times[1]}ms` : "فشل",
        "محاولة 3": times[2] >= 0 ? `${times[2]}ms` : "فشل",
        "متوسط زمن الاستجابة": avg !== null ? `${avg}ms` : "تعذر الاتصال",
        "الحالة": avg !== null ? (avg < 100 ? "ممتاز" : avg < 300 ? "جيد" : "بطيء") : "غير متاح",
      }};
    }

    // HTTP Headers
    if (cleanSlug === "http-headers") {
      const url = input.url?.trim();
      if (!url) return { success: false, error: "أدخل عنوان URL" };
      const target = url.startsWith("http") ? url : `https://${url}`;
      let resp: Response;
      try { resp = await fetch(target, { method: "HEAD", signal: AbortSignal.timeout(8000) }); }
      catch (e: any) { return { success: false, error: `تعذر الاتصال: ${e.message}` }; }
      const headers: Record<string, string> = {};
      resp.headers.forEach((val, key) => { if (!["set-cookie"].includes(key)) headers[key] = val; });
      return { success: true, data: { "الرابط": target, "الحالة": resp.status, ...headers } };
    }

    // SSL Check
    if (cleanSlug === "ssl-check") {
      const domain = input.domain?.trim() || input.url?.trim();
      if (!domain) return { success: false, error: "أدخل اسم النطاق" };
      const host = domain.replace(/^https?:\/\//, "").split("/")[0];
      try {
        const resp = await fetch(`https://${host}`, { method: "HEAD", signal: AbortSignal.timeout(8000) });
        return { success: true, data: {
          "النطاق": host, "SSL": "صالح", "الحالة": "آمن (HTTPS)", "كود الاستجابة": resp.status,
          "رأس الأمان": resp.headers.get("strict-transport-security") || "غير محدد",
        }};
      } catch (e: any) {
        return { success: false, error: `لا يوجد شهادة SSL صالحة أو تعذر الاتصال: ${e.message}` };
      }
    }

    // Password Generator
    if (cleanSlug === "password-gen") {
      const length = Math.min(Math.max(parseInt(input.length || "16", 10), 8), 64);
      const useUpper = input.uppercase !== "false";
      const useLower = input.lowercase !== "false";
      const useNumbers = input.numbers !== "false";
      const useSymbols = input.symbols === "true";
      let chars = "";
      if (useUpper) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      if (useLower) chars += "abcdefghijklmnopqrstuvwxyz";
      if (useNumbers) chars += "0123456789";
      if (useSymbols) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?";
      if (!chars) chars = "abcdefghijklmnopqrstuvwxyz0123456789";
      let password = "";
      const bytes = crypto.randomBytes(length * 2);
      for (let i = 0; i < length; i++) password += chars[bytes[i] % chars.length];
      const strength = length >= 16 && useSymbols ? "قوية جداً" : length >= 12 ? "قوية" : length >= 8 ? "متوسطة" : "ضعيفة";
      return { success: true, data: {
        "كلمة المرور": password, "الطول": length, "القوة": strength,
        "أحرف كبيرة": useUpper ? "نعم" : "لا", "أحرف صغيرة": useLower ? "نعم" : "لا",
        "أرقام": useNumbers ? "نعم" : "لا", "رموز خاصة": useSymbols ? "نعم" : "لا",
      }};
    }

    // JSON Editor / Formatter
    if (cleanSlug === "json-editor") {
      const raw = input.json?.trim();
      if (!raw) return { success: false, error: "أدخل نص JSON" };
      try {
        const parsed = JSON.parse(raw);
        const formatted = JSON.stringify(parsed, null, 2);
        const keys = typeof parsed === "object" && parsed !== null ? Object.keys(parsed).length : 0;
        return { success: true, data: { "JSON المنسق": formatted, "عدد المفاتيح": keys, "الحالة": "صالح" } };
      } catch (e: any) {
        return { success: false, error: `خطأ في صيغة JSON: ${e.message}` };
      }
    }

    // WHOIS (basic)
    if (cleanSlug === "whois") {
      const domain = input.domain?.trim();
      if (!domain) return { success: false, error: "أدخل اسم النطاق" };
      // Use a free WHOIS API
      try {
        const resp = await fetch(`https://api.whois.vu/?q=${domain}`, { signal: AbortSignal.timeout(8000) });
        const text = await resp.text();
        return { success: true, data: { "النطاق": domain, "معلومات WHOIS": text.substring(0, 1000) } };
      } catch {
        return { success: true, data: { "النطاق": domain, "ملاحظة": "لم نتمكن من الوصول لخدمة WHOIS في الوقت الحالي" } };
      }
    }

    // Port Scanner (limited)
    if (cleanSlug === "port-scan") {
      return { success: true, data: {
        "ملاحظة": "فحص المنافذ يتطلب صلاحيات خاصة في البيئة الحالية",
        "بديل": "استخدم nmap أو Shodan للفحص الكامل",
        "المنافذ الشائعة": "80 (HTTP), 443 (HTTPS), 22 (SSH), 21 (FTP), 3306 (MySQL)",
      }};
    }

    return { success: false, error: `الأداة غير معروفة: ${cleanSlug}` };
  } catch (e: any) {
    return { success: false, error: `خطأ في التنفيذ: ${e.message}` };
  }
}

router.post("/tools/execute", async (req, res): Promise<void> => {
  const { slug, input } = req.body;
  if (!slug) { res.status(400).json({ success: false, error: "مطلوب تحديد الأداة" }); return; }

  // Check if tool is premium and user has enough points
  const cleanSlug = slug.replace(/^\/tools\//, "");
  const [tool] = await db.select().from(toolsTable).where(eq(toolsTable.url, `/tools/${cleanSlug}`));

  const userId = (req.session as any)?.userId;
  let pointsSpent: number | null = null;

  if (tool?.isPremium) {
    if (!userId) { res.status(401).json({ success: false, error: "يجب تسجيل الدخول لاستخدام هذه الأداة" }); return; }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    const cost = 5;
    if ((user?.points ?? 0) < cost) {
      res.status(400).json({ success: false, error: `تحتاج ${cost} نقاط لاستخدام هذه الأداة. رصيدك: ${user?.points ?? 0}` });
      return;
    }
    await db.update(usersTable).set({ points: sql`points - ${cost}` }).where(eq(usersTable.id, userId));
    await db.insert(pointTransactionsTable).values({
      fromUserId: userId, toUserId: userId, amount: cost, type: "spent", note: `استخدام أداة: ${tool.name}`,
    });
    pointsSpent = cost;
  }

  const result = await executeToolLogic(cleanSlug, input || {});
  res.json({ ...result, pointsSpent });
});

export default router;
