import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/lib/auth";
import { Layout } from "@/components/layout";

// Pages
import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Tools from "@/pages/tools";
import ToolRunner from "@/pages/tool-runner";
import Chat from "@/pages/chat";
import Support from "@/pages/support/index";
import TicketView from "@/pages/support/[id]";
import Tasks from "@/pages/tasks";
import PhoneNumbers from "@/pages/phone-numbers";
import FileCreator from "@/pages/file-creator";

// Admin Pages
import AdminDashboard from "@/pages/admin/index";
import AdminTools from "@/pages/admin/tools";
import AdminCategories from "@/pages/admin/categories";
import AdminTickets from "@/pages/admin/tickets";
import AdminChat from "@/pages/admin/chat";
import AdminPlans from "@/pages/admin/plans";
import AdminPoints from "@/pages/admin/points";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/tools" component={Tools} />
        <Route path="/tool/:slug" component={ToolRunner} />
        <Route path="/chat" component={Chat} />
        <Route path="/support" component={Support} />
        <Route path="/support/:id" component={TicketView} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/plans" component={Tasks} />
        <Route path="/phone-numbers" component={PhoneNumbers} />
        <Route path="/file-creator" component={FileCreator} />

        {/* Admin Routes */}
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/tools" component={AdminTools} />
        <Route path="/admin/categories" component={AdminCategories} />
        <Route path="/admin/tickets" component={AdminTickets} />
        <Route path="/admin/chat" component={AdminChat} />
        <Route path="/admin/plans" component={AdminPlans} />
        <Route path="/admin/points" component={AdminPoints} />

        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
