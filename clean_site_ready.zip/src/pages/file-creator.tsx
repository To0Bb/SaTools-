import { useState, useCallback } from "react";
import { FileText, Download, Trash2, Code, FileJson, FileType } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface FileFormat {
  ext: string;
  label: string;
  mime: string;
  icon: React.ReactNode;
  placeholder: string;
  language: string;
}

const FILE_FORMATS: FileFormat[] = [
  { ext: "txt",  label: "نص عادي (.txt)",        mime: "text/plain",               icon: <FileText className="w-4 h-4" />, placeholder: "اكتب نصك هنا...",                                            language: "plain" },
  { ext: "py",   label: "Python (.py)",           mime: "text/x-python",            icon: <Code className="w-4 h-4" />,     placeholder: "# كود Python\nprint('مرحبا بالعالم!')",                     language: "python" },
  { ext: "js",   label: "JavaScript (.js)",       mime: "text/javascript",          icon: <Code className="w-4 h-4" />,     placeholder: "// كود JavaScript\nconsole.log('Hello World!');",         language: "js" },
  { ext: "ts",   label: "TypeScript (.ts)",       mime: "text/typescript",          icon: <Code className="w-4 h-4" />,     placeholder: "// كود TypeScript\nconst msg: string = 'Hello';",         language: "ts" },
  { ext: "html", label: "HTML (.html)",           mime: "text/html",                icon: <Code className="w-4 h-4" />,     placeholder: "<!DOCTYPE html>\n<html>\n<body>\n  <h1>مرحبا</h1>\n</body>\n</html>", language: "html" },
  { ext: "css",  label: "CSS (.css)",             mime: "text/css",                 icon: <Code className="w-4 h-4" />,     placeholder: "/* CSS styles */\nbody {\n  margin: 0;\n  direction: rtl;\n}", language: "css" },
  { ext: "json", label: "JSON (.json)",           mime: "application/json",         icon: <FileJson className="w-4 h-4" />, placeholder: '{\n  "اسم": "قيمة"\n}',                                    language: "json" },
  { ext: "md",   label: "Markdown (.md)",         mime: "text/markdown",            icon: <FileText className="w-4 h-4" />, placeholder: "# العنوان\n\nمحتوى الملف هنا...",                          language: "md" },
  { ext: "xml",  label: "XML (.xml)",             mime: "application/xml",          icon: <Code className="w-4 h-4" />,     placeholder: "<?xml version=\"1.0\"?>\n<root>\n  <item>قيمة</item>\n</root>", language: "xml" },
  { ext: "csv",  label: "CSV (.csv)",             mime: "text/csv",                 icon: <FileType className="w-4 h-4" />, placeholder: "اسم,قيمة\nعمود1,بيانات1\nعمود2,بيانات2",                  language: "csv" },
  { ext: "sh",   label: "Shell Script (.sh)",     mime: "text/x-shellscript",       icon: <Code className="w-4 h-4" />,     placeholder: "#!/bin/bash\necho 'مرحبا'",                               language: "sh" },
  { ext: "bat",  label: "Batch Script (.bat)",    mime: "text/plain",               icon: <Code className="w-4 h-4" />,     placeholder: "@echo off\necho مرحبا",                                   language: "bat" },
  { ext: "yaml", label: "YAML (.yaml)",           mime: "text/yaml",                icon: <FileText className="w-4 h-4" />, placeholder: "key: value\nlist:\n  - item1\n  - item2",                 language: "yaml" },
  { ext: "sql",  label: "SQL (.sql)",             mime: "application/sql",          icon: <Code className="w-4 h-4" />,     placeholder: "-- استعلام SQL\nSELECT * FROM users;",                    language: "sql" },
  { ext: "php",  label: "PHP (.php)",             mime: "text/x-php",               icon: <Code className="w-4 h-4" />,     placeholder: "<?php\necho 'مرحبا بالعالم!';",                          language: "php" },
  { ext: "pdf",  label: "PDF (.pdf)",             mime: "application/pdf",          icon: <FileType className="w-4 h-4" />, placeholder: "اكتب محتوى الملف هنا، سيتم تحويله إلى PDF...",          language: "plain" },
];

function downloadTextFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function downloadAsPdf(title: string, content: string) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const maxWidth = pageWidth - margin * 2;

  // Title
  const titleLines = doc.splitTextToSize(title, maxWidth);
  doc.text(titleLines, margin, 30);

  // Content
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  const contentLines = doc.splitTextToSize(content, maxWidth);
  let y = 50;
  const lineHeight = 6;
  const pageHeight = doc.internal.pageSize.getHeight();

  for (const line of contentLines) {
    if (y + lineHeight > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
    doc.text(line, margin, y);
    y += lineHeight;
  }

  doc.save(`${title}.pdf`);
}

export default function FileCreator() {
  const { toast } = useToast();
  const [format, setFormat] = useState<FileFormat>(FILE_FORMATS[0]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const selectedFormat = FILE_FORMATS.find(f => f.ext === format.ext) ?? FILE_FORMATS[0];

  function handleFormatChange(ext: string) {
    const f = FILE_FORMATS.find(f => f.ext === ext);
    if (f) {
      setFormat(f);
      if (!content) setContent("");
    }
  }

  function clearAll() {
    setTitle("");
    setContent("");
  }

  const handleDownload = useCallback(async () => {
    if (!title.trim()) {
      toast({ title: "خطأ", description: "يرجى إدخال عنوان للملف", variant: "destructive" });
      return;
    }
    if (!content.trim()) {
      toast({ title: "خطأ", description: "يرجى كتابة محتوى الملف", variant: "destructive" });
      return;
    }

    setIsGenerating(true);
    try {
      const filename = `${title.trim().replace(/\s+/g, "_")}.${format.ext}`;
      if (format.ext === "pdf") {
        await downloadAsPdf(title.trim(), content);
      } else {
        downloadTextFile(filename, content, format.mime);
      }
      toast({ title: "تم التنزيل", description: `تم إنشاء الملف: ${filename}` });
    } catch (e) {
      toast({ title: "خطأ", description: "حدث خطأ أثناء إنشاء الملف", variant: "destructive" });
    } finally {
      setIsGenerating(false);
    }
  }, [title, content, format, toast]);

  const charCount = content.length;
  const lineCount = content.split("\n").length;

  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          منشئ الملفات
        </h1>
        <p className="text-muted-foreground">اختر صيغة الملف، اكتب المحتوى، ثم نزّله مباشرة.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left panel: settings */}
        <div className="lg:col-span-1 space-y-5">
          <div className="bg-card border border-border rounded-xl p-5 space-y-4">
            <h2 className="font-semibold text-white text-sm border-b border-border pb-3">إعدادات الملف</h2>

            {/* Format selection */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">صيغة الملف</Label>
              <Select value={format.ext} onValueChange={handleFormatChange}>
                <SelectTrigger className="bg-background border-border text-white" data-testid="select-format">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card border-border max-h-64">
                  {FILE_FORMATS.map((f) => (
                    <SelectItem key={f.ext} value={f.ext} className="text-white hover:bg-primary/10">
                      <span className="flex items-center gap-2">
                        {f.icon}
                        {f.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* File title */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">اسم الملف (بدون امتداد)</Label>
              <Input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="مثال: my_script"
                className="bg-background border-border text-white placeholder:text-muted-foreground"
                dir="ltr"
                data-testid="input-filename"
              />
              {title && (
                <p className="text-[11px] text-primary font-mono">
                  {title.trim().replace(/\s+/g, "_")}.{format.ext}
                </p>
              )}
            </div>

            {/* Stats */}
            <div className="bg-background/50 rounded-lg p-3 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">الأحرف</span>
                <span className="text-white font-mono">{charCount.toLocaleString("ar")}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">الأسطر</span>
                <span className="text-white font-mono">{lineCount.toLocaleString("ar")}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">الحجم التقريبي</span>
                <span className="text-white font-mono">
                  {charCount < 1024 ? `${charCount} B` : `${(charCount / 1024).toFixed(1)} KB`}
                </span>
              </div>
            </div>
          </div>

          {/* Supported formats quick list */}
          <div className="bg-card border border-border rounded-xl p-4">
            <h3 className="text-xs font-semibold text-muted-foreground mb-3">الصيغ المدعومة</h3>
            <div className="flex flex-wrap gap-1.5">
              {FILE_FORMATS.map((f) => (
                <button
                  key={f.ext}
                  onClick={() => handleFormatChange(f.ext)}
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors ${
                    format.ext === f.ext
                      ? "bg-primary/20 border-primary/50 text-primary"
                      : "bg-background border-border text-muted-foreground hover:border-primary/30 hover:text-white"
                  }`}
                  data-testid={`btn-format-${f.ext}`}
                >
                  .{f.ext}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right panel: editor */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            {/* Editor toolbar */}
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-background/30">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                {selectedFormat.icon}
                <span className="font-mono">{selectedFormat.label}</span>
              </div>
              <button
                onClick={clearAll}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors"
                data-testid="btn-clear"
              >
                <Trash2 className="w-3 h-3" />
                مسح
              </button>
            </div>

            {/* Textarea */}
            <Textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={selectedFormat.placeholder}
              className="min-h-[400px] rounded-none border-0 bg-background/20 text-white font-mono text-sm resize-none focus-visible:ring-0 placeholder:text-muted-foreground/40 p-4"
              dir="ltr"
              data-testid="textarea-content"
            />
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <Button
              className="flex-1 gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              onClick={handleDownload}
              disabled={isGenerating || !title.trim() || !content.trim()}
              data-testid="btn-download"
            >
              {isGenerating ? (
                <>جاري الإنشاء...</>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  تنزيل الملف
                </>
              )}
            </Button>
            <Button
              variant="outline"
              className="gap-2 border-border text-muted-foreground hover:text-white"
              onClick={clearAll}
              data-testid="btn-clear-all"
            >
              <Trash2 className="w-4 h-4" />
              مسح الكل
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
