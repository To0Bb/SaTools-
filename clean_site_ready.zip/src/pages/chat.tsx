import { useState } from "react";
import { useListChatMessages, useSendChatMessage, useDonatePoints, getListChatMessagesQueryKey, getGetPointsBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, User as UserIcon, Gift, X, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Chat() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [content, setContent] = useState("");
  const [donating, setDonating] = useState<string | null>(null); // username to donate to
  const [donateAmount, setDonateAmount] = useState("10");
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: messages = [] } = useListChatMessages({
    query: { refetchInterval: 5000 }
  });

  const send = useSendChatMessage();
  const donate = useDonatePoints();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && !user) setLocation("/login");
  }, [user, isLoading, setLocation]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  if (isLoading || !user) return <div className="p-8 text-center">جاري التحميل...</div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    try {
      await send.mutateAsync({ data: { content } });
      setContent("");
      queryClient.invalidateQueries({ queryKey: getListChatMessagesQueryKey() });
    } catch {
      toast({ title: "خطأ", description: "لم يتم إرسال الرسالة", variant: "destructive" });
    }
  };

  const handleDonate = async () => {
    if (!donating) return;
    const amount = parseInt(donateAmount, 10);
    if (!amount || amount <= 0) {
      toast({ title: "خطأ", description: "أدخل مبلغاً صحيحاً", variant: "destructive" });
      return;
    }
    try {
      await donate.mutateAsync({ data: { toUsername: donating, amount } });
      toast({ title: "✅ تم التبرع", description: `تبرعت بـ ${amount} نقطة لـ @${donating}` });
      setDonating(null);
      setDonateAmount("10");
      queryClient.invalidateQueries({ queryKey: getGetPointsBalanceQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err?.response?.data?.error || "فشل التبرع", variant: "destructive" });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl h-[calc(100vh-140px)] flex flex-col">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">الشات العام</h1>
          <p className="text-muted-foreground text-sm">تواصل مع أعضاء المنصة — اضغط <Gift className="inline w-4 h-4 text-amber-400" /> للتبرع بنقاط</p>
        </div>
      </div>

      {/* Donate Modal */}
      {donating && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl p-6 w-full max-w-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Gift className="w-5 h-5 text-amber-400" /> تبرع بنقاط
              </h3>
              <button onClick={() => setDonating(null)} className="text-muted-foreground hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">تبرع بنقاطك لـ <span className="text-white font-bold">@{donating}</span></p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-white mb-1.5">عدد النقاط</label>
              <Input
                type="number"
                min="1"
                value={donateAmount}
                onChange={e => setDonateAmount(e.target.value)}
                placeholder="10"
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <Coins className="w-3 h-3" /> رصيدك: {(user as any).points ?? 0} نقطة
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setDonating(null)}>إلغاء</Button>
              <Button className="flex-1 gap-2" onClick={handleDonate} disabled={donate.isPending}>
                <Gift className="w-4 h-4" /> تبرع الآن
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 bg-card border border-border rounded-xl flex flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => {
            const isMe = msg.userId === user.id;
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? "items-start" : "items-end"}`}>
                <div className="flex items-center gap-2 mb-1 text-sm text-muted-foreground">
                  <UserIcon className="w-3 h-3" />
                  <span>{msg.displayName || msg.username}</span>
                  <span className="text-xs opacity-50">
                    {new Date(msg.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {!isMe && (
                    <button
                      onClick={() => setDonating(msg.username)}
                      title={`تبرع بنقاط لـ @${msg.username}`}
                      className="text-muted-foreground hover:text-amber-400 transition-colors opacity-60 hover:opacity-100"
                    >
                      <Gift className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <div className={`px-4 py-2 rounded-2xl max-w-[80%] ${
                  isMe ? "bg-primary text-primary-foreground rounded-tr-none" : "bg-secondary text-secondary-foreground rounded-tl-none"
                }`}>
                  {msg.content}
                </div>
              </div>
            );
          })}
          {messages.length === 0 && (
            <div className="text-center text-muted-foreground py-10">
              لا توجد رسائل بعد. كن أول من يكتب!
            </div>
          )}
        </div>

        <div className="p-4 bg-background border-t border-border">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              className="flex-1"
              placeholder="اكتب رسالتك هنا..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              disabled={send.isPending}
            />
            <Button type="submit" disabled={send.isPending || !content.trim()}>
              <Send className="w-4 h-4 ml-2" /> إرسال
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
