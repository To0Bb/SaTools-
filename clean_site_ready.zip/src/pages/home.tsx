import { Link } from "wouter";
import { useListCategories, useListTools, useGetSiteStats } from "@workspace/api-client-react";
import { Search, ChevronLeft, Terminal, Activity, Globe, Shield, Zap, Users, Eye, UserCheck } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState, useEffect, useRef } from "react";

const getIcon = (name: string) => {
  const icons: Record<string, React.ElementType> = {
    Terminal, Activity, Globe, Shield, Zap, Search
  };
  const Icon = icons[name] || Globe;
  return <Icon className="w-5 h-5" />;
};

function AnimatedNumber({ target, duration = 1800 }: { target: number; duration?: number }) {
  const [current, setCurrent] = useState(0);
  const startRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (target === 0) return;
    startRef.current = null;
    const step = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const progress = Math.min((ts - startRef.current) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCurrent(Math.floor(eased * target));
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration]);

  return <span>{current.toLocaleString("ar-EG")}</span>;
}

export default function Home() {
  const [search, setSearch] = useState("");
  const { data: categories = [] } = useListCategories();
  const { data: tools = [] } = useListTools({ search });
  const { data: stats } = useGetSiteStats({ query: { refetchInterval: 30000 } });

  const statsCards = [
    {
      icon: Eye,
      label: "إجمالي الزيارات",
      value: stats?.totalVisitors ?? 0,
      color: "text-blue-400",
      bg: "bg-blue-400/10",
      border: "border-blue-400/20",
    },
    {
      icon: Activity,
      label: "النشطون الآن",
      value: stats?.activeUsers ?? 0,
      color: "text-green-400",
      bg: "bg-green-400/10",
      border: "border-green-400/20",
      pulse: true,
    },
    {
      icon: Users,
      label: "المشتركون",
      value: stats?.totalMembers ?? 0,
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/20",
    },
    {
      icon: Zap,
      label: "الأدوات المتاحة",
      value: stats?.totalTools ?? 0,
      color: "text-amber-400",
      bg: "bg-amber-400/10",
      border: "border-amber-400/20",
    },
  ];

  return (
    <div className="flex flex-col gap-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-card border-b border-border py-24">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="container mx-auto px-4 relative z-10 flex flex-col items-center text-center gap-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-sm font-medium mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            منصة الأدوات العربية الأولى
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight">
            50+ أداة <span className="text-primary">احترافية</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            مجموعة متكاملة من الأدوات التقنية للمطورين، مديري الأنظمة، ومحترفي الأمن السيبراني في مكان واحد.
          </p>

          <div className="w-full max-w-xl mt-8 relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              className="w-full pl-4 pr-12 py-6 text-lg bg-background border-border rounded-xl shadow-2xl focus-visible:ring-primary"
              placeholder="ابحث عن أداة (مثال: فحص البورتات)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4 -mt-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {statsCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.label}
                className={`bg-card border ${card.border} rounded-2xl p-5 flex flex-col gap-3 hover:scale-[1.02] transition-transform`}
              >
                <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center ${card.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <div className={`text-2xl font-black ${card.color} flex items-center gap-1`}>
                    <AnimatedNumber target={card.value} />
                    {card.pulse && (
                      <span className="inline-flex h-2 w-2 mr-1">
                        <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400"></span>
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">{card.label}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Categories & Tools */}
      <section className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">أحدث الأدوات</h2>
            <p className="text-muted-foreground">تصفح مجموعة من أفضل الأدوات المتاحة</p>
          </div>
          <Link href="/tools" className="text-primary hover:text-primary/80 flex items-center gap-1 font-medium transition-colors">
            عرض الكل <ChevronLeft className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {tools.slice(0, 8).map(tool => (
            <a
              key={tool.id}
              href={tool.url || "#"}
              target="_blank"
              rel="noreferrer"
              className="group bg-card border border-border rounded-xl p-6 hover:border-primary/50 hover:bg-secondary/50 transition-all duration-300"
            >
              <div className="w-12 h-12 bg-background border border-border rounded-lg flex items-center justify-center text-primary mb-4 group-hover:scale-110 group-hover:bg-primary/10 transition-transform">
                {getIcon(tool.icon)}
              </div>
              <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">{tool.name}</h3>
              <p className="text-muted-foreground text-sm line-clamp-2">{tool.description}</p>

              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs bg-secondary px-2 py-1 rounded text-muted-foreground">
                  {tool.categoryName}
                </span>
                {tool.isPremium && (
                  <span className="text-xs bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-1 rounded flex items-center gap-1">
                    <Zap className="w-3 h-3" /> برو
                  </span>
                )}
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4">
        <div className="bg-card border border-primary/20 rounded-2xl p-10 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
          <h2 className="text-3xl font-black text-white mb-3 relative">ابدأ مجاناً اليوم</h2>
          <p className="text-muted-foreground mb-6 relative">سجّل حسابك، أكمل المهام اليومية، واكسب نقاط لاستخدام الأدوات المميزة</p>
          <div className="flex gap-4 justify-center flex-wrap relative">
            <Link href="/register" className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold hover:bg-primary/90 transition-colors">
              إنشاء حساب مجاني
            </Link>
            <Link href="/tasks" className="px-6 py-3 bg-secondary text-secondary-foreground rounded-xl font-bold hover:bg-secondary/80 transition-colors border border-border">
              تصفح المهام
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
