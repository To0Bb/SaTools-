import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useLocation, Link } from "wouter";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTransferPoints, useListPointsHistory } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListPointsHistoryQueryKey } from "@workspace/api-client-react";
import { Coins, ArrowRight, Send, History } from "lucide-react";

export default function AdminPoints() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [toUserId, setToUserId] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  const transfer = useTransferPoints();
  const { data: history = [] } = useListPointsHistory();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) setLocation("/");
  }, [user, isLoading, setLocation]);

  if (isLoading || !user || user.role !== "admin") return null;

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!toUserId || !amount) {
      toast({ title: "خطأ", description: "أدخل معرف المستخدم والمبلغ", variant: "destructive" });
      return;
    }
    try {
      await transfer.mutateAsync({ data: { toUserId: parseInt(toUserId, 10), amount: parseInt(amount, 10), note: note || undefined } });
      toast({ title: "✅ تم التحويل", description: `تم تحويل ${amount} نقطة للمستخدم #${toUserId}` });
      setToUserId(""); setAmount(""); setNote("");
      queryClient.invalidateQueries({ queryKey: getListPointsHistoryQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err?.response?.data?.error || "فشل التحويل", variant: "destructive" });
    }
  };

  const typeLabel: Record<string, string> = {
    earned: "مكسوب", transferred: "محوّل", donated: "تبرع", spent: "مُنفق"
  };
  const typeColor: Record<string, string> = {
    earned: "text-green-400", transferred: "text-blue-400", donated: "text-amber-400", spent: "text-red-400"
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <Link href="/admin" className="text-muted-foreground hover:text-white transition-colors">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-white">إدارة النقاط</h1>
      </div>

      {/* Transfer Form */}
      <div className="bg-card border border-border rounded-2xl p-6 mb-8">
        <h2 className="text-lg font-bold text-white mb-5 flex items-center gap-2">
          <Send className="w-5 h-5 text-primary" /> تحويل نقاط لمستخدم
        </h2>
        <form onSubmit={handleTransfer} className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-white mb-1.5">معرف المستخدم (ID)</label>
            <Input
              type="number"
              placeholder="1"
              value={toUserId}
              onChange={e => setToUserId(e.target.value)}
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-1.5">عدد النقاط</label>
            <Input
              type="number"
              placeholder="100"
              min="1"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-1.5">ملاحظة (اختياري)</label>
            <Input
              placeholder="سبب التحويل"
              value={note}
              onChange={e => setNote(e.target.value)}
            />
          </div>
          <div className="md:col-span-3">
            <Button type="submit" disabled={transfer.isPending} className="gap-2">
              <Coins className="w-4 h-4" />
              {transfer.isPending ? "جاري التحويل..." : "تحويل النقاط"}
            </Button>
          </div>
        </form>
      </div>

      {/* History */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-border flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold text-white">سجل المعاملات الأخيرة</h2>
        </div>
        <div className="divide-y divide-border">
          {history.length === 0 ? (
            <div className="px-6 py-10 text-center text-muted-foreground">لا توجد معاملات بعد</div>
          ) : (
            history.map((tx: any) => (
              <div key={tx.id} className="px-6 py-3 flex items-center gap-4">
                <span className={`text-sm font-bold w-16 ${typeColor[tx.type] || "text-white"}`}>
                  {typeLabel[tx.type] || tx.type}
                </span>
                <span className="text-white font-mono text-sm flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5 text-amber-400" /> {tx.amount}
                </span>
                <span className="text-muted-foreground text-sm flex-1">
                  {tx.fromUsername ? `من @${tx.fromUsername} ` : ""}← @{tx.toUsername}
                </span>
                {tx.note && <span className="text-muted-foreground text-xs hidden md:block">{tx.note}</span>}
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(tx.createdAt).toLocaleDateString('ar-EG')}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
