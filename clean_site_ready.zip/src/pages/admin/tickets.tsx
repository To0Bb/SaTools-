import { useEffect } from "react";
import { useListTickets, useUpdateTicket, getListTicketsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ExternalLink } from "lucide-react";

export default function AdminTickets() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: tickets = [] } = useListTickets();
  const updateTicket = useUpdateTicket();

  const handleStatusChange = async (id: number, status: 'open' | 'in_progress' | 'closed') => {
    try {
      await updateTicket.mutateAsync({ id, data: { status } });
      toast({ title: "تم تحديث حالة التذكرة" });
      queryClient.invalidateQueries({ queryKey: getListTicketsQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    }
  };

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">إدارة التذاكر</h1>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-secondary/50">
            <tr>
              <th className="p-4">رقم</th>
              <th className="p-4">الموضوع</th>
              <th className="p-4">المستخدم</th>
              <th className="p-4">التاريخ</th>
              <th className="p-4">الحالة</th>
              <th className="p-4 text-left">تغيير الحالة</th>
              <th className="p-4 text-left">عرض</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {tickets.map(ticket => (
              <tr key={ticket.id} className="hover:bg-secondary/20">
                <td className="p-4 font-medium">#{ticket.id}</td>
                <td className="p-4">{ticket.subject}</td>
                <td className="p-4 text-muted-foreground">{ticket.displayName || ticket.username}</td>
                <td className="p-4 text-muted-foreground text-sm">{new Date(ticket.createdAt).toLocaleDateString('ar-EG')}</td>
                <td className="p-4">
                  <span className={`text-xs px-2 py-1 rounded ${
                    ticket.status === 'open' ? 'bg-blue-500/10 text-blue-500' :
                    ticket.status === 'in_progress' ? 'bg-amber-500/10 text-amber-500' :
                    'bg-primary/10 text-primary'
                  }`}>
                    {ticket.status === 'open' ? 'مفتوح' : ticket.status === 'in_progress' ? 'قيد المعالجة' : 'مغلق'}
                  </span>
                </td>
                <td className="p-4 text-left">
                  <select 
                    className="p-1 text-sm rounded bg-background border border-border"
                    value={ticket.status}
                    onChange={(e) => handleStatusChange(ticket.id, e.target.value as any)}
                  >
                    <option value="open">مفتوح</option>
                    <option value="in_progress">قيد المعالجة</option>
                    <option value="closed">مغلق</option>
                  </select>
                </td>
                <td className="p-4 text-left">
                  <Link href={`/support/${ticket.id}`}>
                    <Button variant="ghost" size="sm"><ExternalLink className="w-4 h-4" /></Button>
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
