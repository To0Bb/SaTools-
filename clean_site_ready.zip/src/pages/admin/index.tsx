import { useGetAdminStats, getGetAdminStatsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useLocation, Link } from "wouter";
import { useEffect } from "react";
import { Users, Wrench, FolderOpen, Ticket, MessageSquare, CheckCircle, CreditCard, Coins } from "lucide-react";

export default function AdminDashboard() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: stats } = useGetAdminStats({
    query: {
      enabled: !!user && user.role === 'admin'
    }
  });

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">لوحة التحكم</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <Users className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">إجمالي المستخدمين</p>
            <h3 className="text-2xl font-bold">{stats?.totalUsers || 0}</h3>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <Wrench className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">الأدوات</p>
            <h3 className="text-2xl font-bold">{stats?.totalTools || 0}</h3>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <FolderOpen className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">الأقسام</p>
            <h3 className="text-2xl font-bold">{stats?.totalCategories || 0}</h3>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <Ticket className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">تذاكر الدعم</p>
            <h3 className="text-2xl font-bold">{stats?.totalTickets || 0}</h3>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <CheckCircle className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">التذاكر المفتوحة</p>
            <h3 className="text-2xl font-bold">{stats?.openTickets || 0}</h3>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-4">
          <div className="p-3 bg-primary/10 text-primary rounded-lg">
            <MessageSquare className="w-8 h-8" />
          </div>
          <div>
            <p className="text-muted-foreground">رسائل الشات</p>
            <h3 className="text-2xl font-bold">{stats?.totalMessages || 0}</h3>
          </div>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-white mb-4">إدارة المحتوى</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link href="/admin/tools" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <Wrench className="text-primary w-6 h-6" /> إدارة الأدوات
        </Link>
        <Link href="/admin/categories" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <FolderOpen className="text-primary w-6 h-6" /> إدارة الأقسام
        </Link>
        <Link href="/admin/tickets" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <Ticket className="text-primary w-6 h-6" /> إدارة التذاكر
        </Link>
        <Link href="/admin/chat" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <MessageSquare className="text-primary w-6 h-6" /> إدارة الشات
        </Link>
        <Link href="/admin/plans" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <CreditCard className="text-primary w-6 h-6" /> إدارة الخطط
        </Link>
        <Link href="/admin/points" className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:bg-secondary/50 transition-colors flex items-center gap-3">
          <Coins className="text-primary w-6 h-6" /> إدارة النقاط
        </Link>
      </div>
    </div>
  );
}
