import { useState, useEffect } from "react";
import { useListTools, useCreateTool, useUpdateTool, useDeleteTool, useListCategories, getListToolsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Trash2, Edit, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";

export default function AdminTools() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: tools = [] } = useListTools();
  const { data: categories = [] } = useListCategories();
  const createTool = useCreateTool();
  const updateTool = useUpdateTool();
  const deleteTool = useDeleteTool();

  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    icon: "",
    url: "",
    categoryId: 0,
    isActive: true,
    isPremium: false
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      icon: "",
      url: "",
      categoryId: categories[0]?.id || 0,
      isActive: true,
      isPremium: false
    });
    setEditingId(null);
  };

  const handleEdit = (tool: any) => {
    setFormData({
      name: tool.name,
      description: tool.description,
      icon: tool.icon,
      url: tool.url || "",
      categoryId: tool.categoryId,
      isActive: tool.isActive,
      isPremium: tool.isPremium || false
    });
    setEditingId(tool.id);
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateTool.mutateAsync({ id: editingId, data: formData });
        toast({ title: "تم تحديث الأداة بنجاح" });
      } else {
        await createTool.mutateAsync({ data: formData });
        toast({ title: "تم إضافة الأداة بنجاح" });
      }
      setOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: getListToolsQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الأداة؟")) {
      try {
        await deleteTool.mutateAsync({ id });
        toast({ title: "تم حذف الأداة" });
        queryClient.invalidateQueries({ queryKey: getListToolsQueryKey() });
      } catch (err: any) {
        toast({ title: "خطأ", description: err.message, variant: "destructive" });
      }
    }
  };

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">إدارة الأدوات</h1>
        <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> أداة جديدة</Button>
          </DialogTrigger>
          <DialogContent dir="rtl" className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل الأداة" : "إضافة أداة جديدة"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div>
                <label className="block text-sm mb-1">اسم الأداة</label>
                <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">الوصف</label>
                <Textarea required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">الرابط (URL)</label>
                <Input dir="ltr" value={formData.url} onChange={e => setFormData({...formData, url: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">الأيقونة (Lucide React)</label>
                <Input dir="ltr" required value={formData.icon} onChange={e => setFormData({...formData, icon: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">القسم</label>
                <select 
                  className="w-full p-2 rounded bg-background border border-border"
                  value={formData.categoryId}
                  onChange={e => setFormData({...formData, categoryId: parseInt(e.target.value)})}
                  required
                >
                  <option value={0} disabled>اختر القسم</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="isActive" checked={formData.isActive} onCheckedChange={(c) => setFormData({...formData, isActive: !!c})} />
                <label htmlFor="isActive">مفعل</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="isPremium" checked={formData.isPremium} onCheckedChange={(c) => setFormData({...formData, isPremium: !!c})} />
                <label htmlFor="isPremium">برو (مدفوع)</label>
              </div>
              <Button type="submit" className="w-full">حفظ</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-secondary/50">
            <tr>
              <th className="p-4">الاسم</th>
              <th className="p-4">القسم</th>
              <th className="p-4">الرابط</th>
              <th className="p-4">الحالة</th>
              <th className="p-4 text-left">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {tools.map(tool => (
              <tr key={tool.id} className="hover:bg-secondary/20">
                <td className="p-4 font-medium">{tool.name} {tool.isPremium && <span className="text-xs text-amber-500 bg-amber-500/10 px-1 rounded mr-2">برو</span>}</td>
                <td className="p-4">{tool.categoryName}</td>
                <td className="p-4 text-muted-foreground" dir="ltr">{tool.url}</td>
                <td className="p-4">
                  {tool.isActive ? <span className="text-green-500">نشط</span> : <span className="text-red-500">معطل</span>}
                </td>
                <td className="p-4 text-left">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(tool)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(tool.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
