import { useEffect } from "react";
import { useListChatMessages, useDeleteChatMessage, getListChatMessagesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Trash2 } from "lucide-react";

export default function AdminChat() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: messages = [] } = useListChatMessages();
  const deleteMessage = useDeleteChatMessage();

  const handleDelete = async (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الرسالة؟")) {
      try {
        await deleteMessage.mutateAsync({ id });
        toast({ title: "تم حذف الرسالة" });
        queryClient.invalidateQueries({ queryKey: getListChatMessagesQueryKey() });
      } catch (err: any) {
        toast({ title: "خطأ", description: err.message, variant: "destructive" });
      }
    }
  };

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">إدارة الشات</h1>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-secondary/50">
            <tr>
              <th className="p-4">المستخدم</th>
              <th className="p-4">الرسالة</th>
              <th className="p-4">التاريخ</th>
              <th className="p-4 text-left">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {messages.map(msg => (
              <tr key={msg.id} className="hover:bg-secondary/20">
                <td className="p-4 font-medium text-primary">{msg.displayName || msg.username}</td>
                <td className="p-4 max-w-md truncate">{msg.content}</td>
                <td className="p-4 text-muted-foreground text-sm">{new Date(msg.createdAt).toLocaleString('ar-EG')}</td>
                <td className="p-4 text-left">
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(msg.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
