import { useState, useEffect } from "react";
import { useListPlans, useCreatePlan, useUpdatePlan, useDeletePlan, getListPlansQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Trash2, Edit, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";

export default function AdminPlans() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: plans = [] } = useListPlans();
  const createPlan = useCreatePlan();
  const updatePlan = useUpdatePlan();
  const deletePlan = useDeletePlan();

  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState<{
    name: string;
    price: number;
    period: 'monthly' | 'yearly' | 'lifetime';
    features: string[];
    isActive: boolean;
    isPopular: boolean;
  }>({
    name: "",
    price: 0,
    period: 'monthly',
    features: [],
    isActive: true,
    isPopular: false
  });
  
  const [featuresText, setFeaturesText] = useState("");

  const resetForm = () => {
    setFormData({
      name: "",
      price: 0,
      period: 'monthly',
      features: [],
      isActive: true,
      isPopular: false
    });
    setFeaturesText("");
    setEditingId(null);
  };

  const handleEdit = (plan: any) => {
    setFormData({
      name: plan.name,
      price: plan.price,
      period: plan.period,
      features: plan.features,
      isActive: plan.isActive,
      isPopular: plan.isPopular || false
    });
    setFeaturesText(plan.features.join("\n"));
    setEditingId(plan.id);
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSubmit = {
      ...formData,
      features: featuresText.split("\n").filter(f => f.trim().length > 0)
    };

    try {
      if (editingId) {
        await updatePlan.mutateAsync({ id: editingId, data: dataToSubmit });
        toast({ title: "تم تحديث الخطة بنجاح" });
      } else {
        await createPlan.mutateAsync({ data: dataToSubmit });
        toast({ title: "تم إضافة الخطة بنجاح" });
      }
      setOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: getListPlansQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الخطة؟")) {
      try {
        await deletePlan.mutateAsync({ id });
        toast({ title: "تم حذف الخطة" });
        queryClient.invalidateQueries({ queryKey: getListPlansQueryKey() });
      } catch (err: any) {
        toast({ title: "خطأ", description: err.message, variant: "destructive" });
      }
    }
  };

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">إدارة الخطط</h1>
        <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> خطة جديدة</Button>
          </DialogTrigger>
          <DialogContent dir="rtl" className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل الخطة" : "إضافة خطة جديدة"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div>
                <label className="block text-sm mb-1">اسم الخطة</label>
                <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1">السعر ($)</label>
                  <Input type="number" step="0.01" required value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} />
                </div>
                <div>
                  <label className="block text-sm mb-1">الفترة</label>
                  <select 
                    className="w-full p-2 rounded bg-background border border-border"
                    value={formData.period}
                    onChange={e => setFormData({...formData, period: e.target.value as any})}
                  >
                    <option value="monthly">شهرياً</option>
                    <option value="yearly">سنوياً</option>
                    <option value="lifetime">مدى الحياة</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm mb-1">المميزات (كل ميزة في سطر)</label>
                <Textarea rows={5} required value={featuresText} onChange={e => setFeaturesText(e.target.value)} />
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="isActive" checked={formData.isActive} onCheckedChange={(c) => setFormData({...formData, isActive: !!c})} />
                <label htmlFor="isActive">مفعل</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="isPopular" checked={formData.isPopular} onCheckedChange={(c) => setFormData({...formData, isPopular: !!c})} />
                <label htmlFor="isPopular">الأكثر شعبية (مميزة)</label>
              </div>
              <Button type="submit" className="w-full">حفظ</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-secondary/50">
            <tr>
              <th className="p-4">الاسم</th>
              <th className="p-4">السعر</th>
              <th className="p-4">الفترة</th>
              <th className="p-4 text-left">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {plans.map(plan => (
              <tr key={plan.id} className="hover:bg-secondary/20">
                <td className="p-4 font-medium">
                  {plan.name} {plan.isPopular && <span className="text-xs text-primary bg-primary/10 px-1 rounded mr-2">شائعة</span>}
                  {!plan.isActive && <span className="text-xs text-red-500 bg-red-500/10 px-1 rounded mr-2">معطلة</span>}
                </td>
                <td className="p-4">${plan.price}</td>
                <td className="p-4">{plan.period === 'monthly' ? 'شهرياً' : plan.period === 'yearly' ? 'سنوياً' : 'مدى الحياة'}</td>
                <td className="p-4 text-left">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(plan)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(plan.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
