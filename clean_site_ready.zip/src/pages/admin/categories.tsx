import { useState, useEffect } from "react";
import { useListCategories, useCreateCategory, useUpdateCategory, useDeleteCategory, getListCategoriesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Trash2, Edit, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminCategories() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { data: categories = [] } = useListCategories();
  const createCategory = useCreateCategory();
  const updateCategory = useUpdateCategory();
  const deleteCategory = useDeleteCategory();

  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    icon: ""
  });

  const resetForm = () => {
    setFormData({ name: "", description: "", icon: "" });
    setEditingId(null);
  };

  const handleEdit = (category: any) => {
    setFormData({
      name: category.name,
      description: category.description || "",
      icon: category.icon
    });
    setEditingId(category.id);
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateCategory.mutateAsync({ id: editingId, data: formData });
        toast({ title: "تم تحديث القسم بنجاح" });
      } else {
        await createCategory.mutateAsync({ data: formData });
        toast({ title: "تم إضافة القسم بنجاح" });
      }
      setOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا القسم؟ قد يؤدي هذا لحذف الأدوات المرتبطة به!")) {
      try {
        await deleteCategory.mutateAsync({ id });
        toast({ title: "تم حذف القسم" });
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      } catch (err: any) {
        toast({ title: "خطأ", description: err.message, variant: "destructive" });
      }
    }
  };

  if (isLoading || !user || user.role !== 'admin') return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">إدارة الأقسام</h1>
        <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> قسم جديد</Button>
          </DialogTrigger>
          <DialogContent dir="rtl">
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل القسم" : "إضافة قسم جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div>
                <label className="block text-sm mb-1">اسم القسم</label>
                <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">الوصف</label>
                <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm mb-1">الأيقونة (Lucide React)</label>
                <Input dir="ltr" required value={formData.icon} onChange={e => setFormData({...formData, icon: e.target.value})} />
              </div>
              <Button type="submit" className="w-full">حفظ</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-secondary/50">
            <tr>
              <th className="p-4">الاسم</th>
              <th className="p-4">الوصف</th>
              <th className="p-4">الأيقونة</th>
              <th className="p-4 text-left">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {categories.map(category => (
              <tr key={category.id} className="hover:bg-secondary/20">
                <td className="p-4 font-medium">{category.name}</td>
                <td className="p-4 text-muted-foreground">{category.description}</td>
                <td className="p-4 text-muted-foreground" dir="ltr">{category.icon}</td>
                <td className="p-4 text-left">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(category)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(category.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
