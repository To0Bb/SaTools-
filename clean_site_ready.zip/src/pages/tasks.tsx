import { useState } from "react";
import { useListTasks, useCompleteTask, useGetPointsBalance, getListTasksQueryKey, getGetPointsBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { 
  Star, MessageSquare, Network, HelpCircle, Globe, Key, MapPin, MessageCircle, 
  Shield, User, Gift, Layers, LogIn, CheckCircle2, Lock, Coins, Trophy, Zap
} from "lucide-react";

const iconMap: Record<string, React.ElementType> = {
  Star, MessageSquare, Network, HelpCircle, Globe, Key, MapPin, MessageCircle,
  Shield, User, Gift, Layers, LogIn, CheckCircle2, Lock, Coins, Trophy, Zap
};

const getIcon = (name: string) => {
  const Icon = iconMap[name] || Star;
  return <Icon className="w-6 h-6" />;
};

export default function Tasks() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks = [], isLoading: tasksLoading } = useListTasks();
  const { data: balance } = useGetPointsBalance({ query: { enabled: !!user } });
  const completeTask = useCompleteTask();

  useEffect(() => {
    if (!isLoading && !user) setLocation("/login");
  }, [user, isLoading, setLocation]);

  if (isLoading || !user) return <div className="p-8 text-center text-muted-foreground">جاري التحميل...</div>;

  const handleComplete = async (taskId: number) => {
    try {
      const result = await completeTask.mutateAsync({ id: taskId });
      toast({
        title: "🎉 أحسنت!",
        description: `${result.message} — رصيدك الآن: ${result.newBalance} نقطة`,
      });
      queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetPointsBalanceQueryKey() });
    } catch (err: any) {
      toast({
        title: "تنبيه",
        description: err?.response?.data?.error || "لم يتم إتمام المهمة",
        variant: "destructive",
      });
    }
  };

  const dailyTasks = tasks.filter(t => t.taskType === "daily");
  const onceTasks = tasks.filter(t => t.taskType === "once");
  const completedCount = tasks.filter(t => t.completedToday).length;

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">المهام اليومية</h1>
        <p className="text-muted-foreground">أكمل المهام واكسب النقاط لاستخدام الأدوات المميزة</p>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-card border border-border rounded-xl p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">رصيدك الحالي</p>
            <h3 className="text-2xl font-black text-primary">{balance?.balance ?? user.points ?? 0} نقطة</h3>
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center text-green-500">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">مكتملة اليوم</p>
            <h3 className="text-2xl font-black text-white">{completedCount} / {dailyTasks.length}</h3>
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-500">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">مجموع ما كسبته</p>
            <h3 className="text-2xl font-black text-white">{balance?.totalEarned ?? 0} نقطة</h3>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-card border border-border rounded-xl p-4 mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-white">تقدم اليوم</span>
          <span className="text-sm text-muted-foreground">{completedCount} من {dailyTasks.length} مهمة يومية</span>
        </div>
        <div className="w-full bg-secondary rounded-full h-2.5">
          <div
            className="bg-primary h-2.5 rounded-full transition-all duration-500"
            style={{ width: dailyTasks.length ? `${(completedCount / dailyTasks.length) * 100}%` : "0%" }}
          />
        </div>
      </div>

      {tasksLoading ? (
        <div className="text-center py-12 text-muted-foreground">جاري تحميل المهام...</div>
      ) : (
        <>
          {/* Daily Tasks */}
          <div className="mb-8">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-400" /> المهام اليومية
              <span className="text-sm font-normal text-muted-foreground">(تتجدد كل يوم)</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {dailyTasks.map(task => (
                <div
                  key={task.id}
                  className={`bg-card border rounded-xl p-5 flex gap-4 items-start transition-all ${
                    task.completedToday ? "border-primary/40 bg-primary/5" : "border-border hover:border-border/80"
                  }`}
                >
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${
                    task.completedToday ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"
                  }`}>
                    {task.completedToday ? <CheckCircle2 className="w-6 h-6" /> : getIcon(task.icon)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className={`font-bold mb-1 ${task.completedToday ? "text-primary" : "text-white"}`}>{task.title}</h3>
                      <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full whitespace-nowrap shrink-0">
                        +{task.pointsReward} نقطة
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                    {task.completedToday ? (
                      <span className="text-xs text-primary font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> تم إتمامها اليوم
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleComplete(task.id)}
                        disabled={completeTask.isPending}
                        className="h-7 text-xs border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
                      >
                        إتمام المهمة
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Once Tasks */}
          {onceTasks.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" /> مهام لمرة واحدة
                <span className="text-sm font-normal text-muted-foreground">(تكسبها مرة واحدة فقط)</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {onceTasks.map(task => (
                  <div
                    key={task.id}
                    className={`bg-card border rounded-xl p-5 flex gap-4 items-start transition-all ${
                      task.completedToday ? "border-amber-500/40 bg-amber-500/5" : "border-border hover:border-border/80"
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${
                      task.completedToday ? "bg-amber-500/20 text-amber-400" : "bg-secondary text-muted-foreground"
                    }`}>
                      {task.completedToday ? <CheckCircle2 className="w-6 h-6" /> : getIcon(task.icon)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className={`font-bold mb-1 ${task.completedToday ? "text-amber-400" : "text-white"}`}>{task.title}</h3>
                        <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full whitespace-nowrap shrink-0">
                          +{task.pointsReward} نقطة
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                      {task.completedToday ? (
                        <span className="text-xs text-amber-400 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> تم كسبها
                        </span>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleComplete(task.id)}
                          disabled={completeTask.isPending}
                          className="h-7 text-xs border-amber-500/30 text-amber-400 hover:bg-amber-500 hover:text-white"
                        >
                          إتمام المهمة
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
