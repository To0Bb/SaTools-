import { useState } from "react";
import { useListPublicNumbers, useListNumberMessages } from "@workspace/api-client-react";
import { Phone, Copy, Check, ChevronDown, ChevronUp, Clock, MessageSquare, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { getListNumberMessagesQueryKey, getListPublicNumbersQueryKey } from "@workspace/api-client-react";

function formatRelativeTime(dateStr: string) {
  const date = new Date(dateStr);
  const diffMs = Date.now() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return "الآن";
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;
  return `منذ ${Math.floor(diffHours / 24)} يوم`;
}

function extractCode(message: string): string | null {
  const patterns = [
    /\b(\d{4,8})\b/,
    /[A-Z0-9]{4,10}/,
  ];
  for (const p of patterns) {
    const m = message.match(p);
    if (m) return m[0];
  }
  return null;
}

function NumberCard({ number }: { number: { id: number; number: string; country: string; flag: string; countryCode: string; serviceLabel: string; createdAt: string } }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading: loadingMsgs } = useListNumberMessages(number.id, {
    query: {
      enabled: expanded,
      queryKey: getListNumberMessagesQueryKey(number.id),
    },
  });

  function copyNumber() {
    navigator.clipboard.writeText(number.number);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function refresh() {
    queryClient.invalidateQueries({ queryKey: getListNumberMessagesQueryKey(number.id) });
  }

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden transition-all duration-200 hover:border-primary/40"
      data-testid={`card-number-${number.id}`}
    >
      {/* Header */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{number.flag}</span>
            <div>
              <p className="text-xs text-muted-foreground">{number.country}</p>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-primary/30 text-primary mt-0.5">
                {number.serviceLabel}
              </Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-white"
            onClick={copyNumber}
            data-testid={`btn-copy-${number.id}`}
          >
            {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>

        {/* The phone number — big and clear */}
        <div
          className="font-mono text-xl font-bold text-white tracking-wider mb-4 cursor-pointer select-all"
          dir="ltr"
          onClick={copyNumber}
          data-testid={`text-number-${number.id}`}
        >
          {number.number}
        </div>

        {/* Toggle messages */}
        <button
          className="w-full flex items-center justify-between text-sm text-muted-foreground hover:text-white transition-colors py-2 border-t border-border"
          onClick={() => setExpanded(v => !v)}
          data-testid={`btn-toggle-messages-${number.id}`}
        >
          <span className="flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5" />
            عرض الرسائل والأكواد
          </span>
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Messages section */}
      {expanded && (
        <div className="border-t border-border bg-background/50">
          <div className="flex items-center justify-between px-4 py-2 border-b border-border/50">
            <span className="text-xs text-muted-foreground">الرسائل المستقبلة</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-muted-foreground hover:text-white"
              onClick={refresh}
              data-testid={`btn-refresh-${number.id}`}
            >
              <RefreshCw className="w-3 h-3" />
            </Button>
          </div>
          {loadingMsgs ? (
            <div className="p-4 text-center text-sm text-muted-foreground">جاري التحميل...</div>
          ) : messages.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">لا توجد رسائل حتى الآن</div>
          ) : (
            <div className="divide-y divide-border/40 max-h-72 overflow-y-auto">
              {[...messages].reverse().map((msg) => {
                const code = extractCode(msg.message);
                return (
                  <div key={msg.id} className="p-3 hover:bg-card/50 transition-colors" data-testid={`msg-item-${msg.id}`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-primary">{msg.sender}</span>
                      <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {formatRelativeTime(msg.receivedAt)}
                      </span>
                    </div>
                    {/* Extracted code highlighted */}
                    {code && (
                      <CodeBadge code={code} />
                    )}
                    <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{msg.message}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function CodeBadge({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  function copy() {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }
  return (
    <button
      className="inline-flex items-center gap-1.5 bg-primary/10 border border-primary/30 rounded px-2 py-1 font-mono font-bold text-primary text-sm hover:bg-primary/20 transition-colors"
      onClick={copy}
      data-testid="btn-copy-code"
    >
      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      {code}
    </button>
  );
}

export default function PhoneNumbers() {
  const queryClient = useQueryClient();
  const { data: numbers = [], isLoading } = useListPublicNumbers();

  function refreshAll() {
    queryClient.invalidateQueries({ queryKey: getListPublicNumbersQueryKey() });
  }

  return (
    <div className="container mx-auto px-4 py-10">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-3xl md:text-4xl font-bold text-white flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
              <Phone className="w-5 h-5 text-primary" />
            </div>
            الأرقام الدولية المجانية
          </h1>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 border-border text-muted-foreground hover:text-white"
            onClick={refreshAll}
            data-testid="btn-refresh-all"
          >
            <RefreshCw className="w-4 h-4" />
            تحديث
          </Button>
        </div>
        <p className="text-muted-foreground text-base max-w-2xl">
          أرقام هواتف دولية عامة يمكنك استخدامها لاستقبال رسائل التحقق (OTP). اضغط على الرقم لنسخه، ثم اعرض الأكواد الواردة.
        </p>
      </div>

      {/* Numbers grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-card border border-border rounded-xl h-40 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {numbers.map((n) => (
            <NumberCard key={n.id} number={n} />
          ))}
        </div>
      )}

      {/* Disclaimer */}
      <div className="mt-10 p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-xl">
        <p className="text-xs text-yellow-500/80 text-center">
          هذه الأرقام عامة ومشتركة — لا تستخدمها لأي غرض حساس. الرسائل تظهر للجميع.
        </p>
      </div>
    </div>
  );
}
