import { useState } from "react";
import { useExecuteTool, useGetPointsBalance, getGetPointsBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useParams } from "wouter";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "wouter";
import { ArrowRight, Play, Loader2, Copy, CheckCircle, Coins, AlertCircle } from "lucide-react";

interface ToolConfig {
  name: string;
  description: string;
  isPremium?: boolean;
  cost?: number;
  fields: { key: string; label: string; placeholder: string; type?: "text" | "textarea" | "select"; options?: string[] }[];
}

const toolConfigs: Record<string, ToolConfig> = {
  "ip-lookup": {
    name: "بحث IP",
    description: "اعرف معلومات أي عنوان IP (الدولة، المدينة، مزود الخدمة)",
    fields: [{ key: "ip", label: "عنوان IP", placeholder: "8.8.8.8 (اتركه فارغاً لعنوانك)" }],
  },
  "dns-lookup": {
    name: "فحص DNS",
    description: "استعلم عن سجلات DNS لأي نطاق",
    fields: [
      { key: "domain", label: "اسم النطاق", placeholder: "google.com" },
      {
        key: "type", label: "نوع السجل", placeholder: "A", type: "select",
        options: ["A", "AAAA", "MX", "TXT", "NS", "CNAME"],
      },
    ],
  },
  "ping": {
    name: "اختبار Ping",
    description: "اختبر سرعة الاستجابة لأي موقع أو خادم",
    fields: [{ key: "host", label: "الموقع أو الخادم", placeholder: "google.com" }],
  },
  "speed-test": {
    name: "اختبار سرعة الخادم",
    description: "قس زمن استجابة الخادم",
    isPremium: true, cost: 5,
    fields: [{ key: "url", label: "رابط الخادم", placeholder: "https://example.com" }],
  },
  "http-headers": {
    name: "HTTP Headers",
    description: "اعرض ترويسات HTTP لأي موقع",
    fields: [{ key: "url", label: "رابط الموقع", placeholder: "https://google.com" }],
  },
  "ssl-check": {
    name: "فاحص SSL",
    description: "تحقق من صلاحية شهادة SSL لأي نطاق",
    isPremium: true, cost: 5,
    fields: [{ key: "domain", label: "النطاق", placeholder: "google.com" }],
  },
  "password-gen": {
    name: "مولد كلمة مرور",
    description: "أنشئ كلمات مرور قوية وآمنة",
    fields: [
      { key: "length", label: "الطول", placeholder: "16" },
      { key: "symbols", label: "رموز خاصة (!@#$)", placeholder: "true أو false" },
      { key: "uppercase", label: "أحرف كبيرة", placeholder: "true أو false" },
    ],
  },
  "json-editor": {
    name: "محرر JSON",
    description: "تحقق من صحة JSON ونسّقه بشكل جميل",
    fields: [{ key: "json", label: "نص JSON", placeholder: '{"key": "value"}', type: "textarea" }],
  },
  "whois": {
    name: "WHOIS",
    description: "معلومات تسجيل النطاق",
    isPremium: true, cost: 5,
    fields: [{ key: "domain", label: "النطاق", placeholder: "google.com" }],
  },
  "port-scan": {
    name: "فاحص المنافذ",
    description: "فحص المنافذ المفتوحة",
    isPremium: true, cost: 5,
    fields: [{ key: "host", label: "الهدف", placeholder: "192.168.1.1" }],
  },
};

export default function ToolRunner() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug || "";
  const config = toolConfigs[slug];
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [fields, setFields] = useState<Record<string, string>>({});
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const { data: balance } = useGetPointsBalance({ query: { enabled: !!user } });
  const executeTool = useExecuteTool();

  if (!config) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-white mb-4">الأداة غير موجودة</h1>
        <Link href="/tools" className="text-primary hover:underline">العودة للأدوات</Link>
      </div>
    );
  }

  const handleRun = async () => {
    setResult(null);
    setError(null);
    try {
      const res = await executeTool.mutateAsync({ data: { slug, input: fields } });
      if (res.success && res.data) {
        setResult(res.data as Record<string, unknown>);
        if (res.pointsSpent) {
          toast({ title: `تم خصم ${res.pointsSpent} نقطة`, description: "تم تنفيذ الأداة بنجاح" });
          queryClient.invalidateQueries({ queryKey: getGetPointsBalanceQueryKey() });
        }
      } else {
        setError(res.error ?? "حدث خطأ غير معروف");
      }
    } catch (err: any) {
      setError(err?.response?.data?.error ?? "حدث خطأ في التنفيذ");
    }
  };

  const copyValue = (key: string, val: string) => {
    navigator.clipboard.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const userPoints = balance?.balance ?? (user as any)?.points ?? 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      {/* Back */}
      <Link href="/tools" className="inline-flex items-center gap-2 text-muted-foreground hover:text-white mb-6 text-sm transition-colors">
        <ArrowRight className="w-4 h-4" /> العودة للأدوات
      </Link>

      {/* Header */}
      <div className="bg-card border border-border rounded-2xl p-6 mb-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h1 className="text-2xl font-bold text-white mb-1">{config.name}</h1>
            <p className="text-muted-foreground">{config.description}</p>
          </div>
          {config.isPremium && (
            <div className="flex flex-col items-end gap-1">
              <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-3 py-1 rounded-full flex items-center gap-1 whitespace-nowrap">
                <Coins className="w-3 h-3" /> تكلف {config.cost} نقاط
              </span>
              {user && (
                <span className="text-xs text-muted-foreground">رصيدك: {userPoints} نقطة</span>
              )}
            </div>
          )}
        </div>

        {config.isPremium && !user && (
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 mb-4 flex items-center gap-2 text-sm text-amber-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>يجب <Link href="/login" className="underline">تسجيل الدخول</Link> واستخدام النقاط لتشغيل هذه الأداة</span>
          </div>
        )}
        {config.isPremium && user && userPoints < (config.cost ?? 5) && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 mb-4 flex items-center gap-2 text-sm text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>رصيدك غير كافٍ. تحتاج {config.cost} نقاط. أكمل <Link href="/tasks" className="underline">المهام اليومية</Link> لكسب المزيد!</span>
          </div>
        )}

        {/* Input Fields */}
        <div className="space-y-4">
          {config.fields.map(field => (
            <div key={field.key}>
              <label className="block text-sm font-medium text-white mb-1.5">{field.label}</label>
              {field.type === "textarea" ? (
                <Textarea
                  placeholder={field.placeholder}
                  value={fields[field.key] ?? ""}
                  onChange={e => setFields(prev => ({ ...prev, [field.key]: e.target.value }))}
                  className="font-mono text-sm min-h-[100px]"
                  dir="ltr"
                />
              ) : field.type === "select" ? (
                <select
                  value={fields[field.key] ?? field.options?.[0] ?? ""}
                  onChange={e => setFields(prev => ({ ...prev, [field.key]: e.target.value }))}
                  className="w-full px-3 py-2 bg-background border border-border rounded-lg text-white text-sm"
                >
                  {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              ) : (
                <Input
                  placeholder={field.placeholder}
                  value={fields[field.key] ?? ""}
                  onChange={e => setFields(prev => ({ ...prev, [field.key]: e.target.value }))}
                  dir="ltr"
                  className="font-mono"
                />
              )}
            </div>
          ))}
        </div>

        <Button
          className="mt-5 w-full gap-2"
          size="lg"
          onClick={handleRun}
          disabled={executeTool.isPending || (config.isPremium && !user) || (config.isPremium && userPoints < (config.cost ?? 5))}
        >
          {executeTool.isPending ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> جاري التنفيذ...</>
          ) : (
            <><Play className="w-4 h-4" /> تشغيل الأداة</>
          )}
        </Button>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="bg-card border border-primary/20 rounded-2xl overflow-hidden">
          <div className="px-5 py-3 bg-primary/5 border-b border-primary/20 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">النتيجة</span>
          </div>
          <div className="divide-y divide-border">
            {Object.entries(result).map(([key, val]) => {
              const str = typeof val === "object" ? JSON.stringify(val, null, 2) : String(val);
              const isLong = str.length > 80 || str.includes("\n");
              return (
                <div key={key} className="px-5 py-3 flex items-start gap-3">
                  <span className="text-muted-foreground text-sm w-36 shrink-0 pt-0.5">{key}</span>
                  <div className="flex-1 min-w-0 flex items-start gap-2">
                    {isLong ? (
                      <pre className="flex-1 text-sm text-white font-mono whitespace-pre-wrap break-all bg-background rounded p-2 text-xs">{str}</pre>
                    ) : (
                      <span className="flex-1 text-white text-sm font-mono">{str}</span>
                    )}
                    <button
                      onClick={() => copyValue(key, str)}
                      className="text-muted-foreground hover:text-white transition-colors shrink-0"
                      title="نسخ"
                    >
                      {copied === key ? <CheckCircle className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
