import { useState, useEffect, useRef } from "react";
import { useGetTicket, getGetTicketQueryKey, useListTicketReplies, getListTicketRepliesQueryKey, useReplyToTicket } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useRoute, useLocation, Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ChevronRight, Shield, User as UserIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TicketView() {
  const [match, params] = useRoute("/support/:id");
  const ticketId = params?.id ? parseInt(params.id) : 0;
  
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: ticket } = useGetTicket(ticketId, {
    query: { enabled: !!ticketId && !!user, queryKey: getGetTicketQueryKey(ticketId) }
  });

  const { data: replies = [] } = useListTicketReplies(ticketId, {
    query: { enabled: !!ticketId && !!user, queryKey: getListTicketRepliesQueryKey(ticketId) }
  });

  const reply = useReplyToTicket();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [replies]);

  if (isLoading || !user) return <div className="p-8 text-center">جاري التحميل...</div>;
  if (!ticket) return <div className="p-8 text-center">التذكرة غير موجودة</div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    try {
      await reply.mutateAsync({ id: ticketId, data: { content } });
      setContent("");
      queryClient.invalidateQueries({ queryKey: getListTicketRepliesQueryKey(ticketId) });
    } catch (err: any) {
      toast({
        title: "خطأ",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl h-[calc(100vh-140px)] flex flex-col">
      <div className="mb-6 flex items-center gap-4">
        <Link href="/support" className="p-2 hover:bg-secondary rounded-full transition-colors">
          <ChevronRight className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-white">تذكرة #{ticket.id}: {ticket.subject}</h1>
          <p className="text-muted-foreground text-sm">حالة التذكرة: {ticket.status}</p>
        </div>
      </div>

      <div className="flex-1 bg-card border border-border rounded-xl flex flex-col overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Initial Ticket Message */}
          <div className="flex flex-col items-start">
            <div className="flex items-center gap-2 mb-1 text-sm text-muted-foreground">
              <UserIcon className="w-3 h-3" />
              <span>{ticket.displayName || ticket.username}</span>
              <span className="text-xs opacity-50">
                {new Date(ticket.createdAt).toLocaleString('ar-EG')}
              </span>
            </div>
            <div className="px-4 py-3 rounded-2xl bg-secondary text-secondary-foreground rounded-tr-none w-full">
              {ticket.message}
            </div>
          </div>

          <div className="border-t border-border my-4" />

          {/* Replies */}
          {replies.map((rep) => {
            const isMe = rep.userId === user.id;
            return (
              <div key={rep.id} className={`flex flex-col ${isMe ? "items-start" : "items-end"}`}>
                <div className="flex items-center gap-2 mb-1 text-sm text-muted-foreground">
                  {rep.isAdmin ? <Shield className="w-3 h-3 text-primary" /> : <UserIcon className="w-3 h-3" />}
                  <span className={rep.isAdmin ? "text-primary font-bold" : ""}>
                    {rep.isAdmin ? "فريق الدعم" : (rep.displayName || rep.username)}
                  </span>
                  <span className="text-xs opacity-50">
                    {new Date(rep.createdAt).toLocaleString('ar-EG')}
                  </span>
                </div>
                <div className={`px-4 py-3 rounded-2xl max-w-[85%] ${
                  isMe 
                    ? "bg-secondary text-secondary-foreground rounded-tr-none" 
                    : "bg-primary/20 text-white border border-primary/30 rounded-tl-none"
                }`}>
                  {rep.content}
                </div>
              </div>
            );
          })}
        </div>

        {ticket.status !== 'closed' ? (
          <div className="p-4 bg-background border-t border-border">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                className="flex-1"
                placeholder="اكتب ردك هنا..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                disabled={reply.isPending}
              />
              <Button type="submit" disabled={reply.isPending || !content.trim()}>
                إرسال الرد
              </Button>
            </form>
          </div>
        ) : (
          <div className="p-4 bg-background border-t border-border text-center text-muted-foreground">
            هذه التذكرة مغلقة ولا يمكن الرد عليها.
          </div>
        )}
      </div>
    </div>
  );
}
