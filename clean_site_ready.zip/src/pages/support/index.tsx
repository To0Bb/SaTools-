import { useState, useEffect } from "react";
import { useListTickets, useCreateTicket, getListTicketsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation, Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MessageSquare, Plus, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Support() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const { data: tickets = [] } = useListTickets({
    query: {
      enabled: !!user
    }
  });

  const createTicket = useCreateTicket();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading || !user) return <div className="p-8 text-center">جاري التحميل...</div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createTicket.mutateAsync({ data: { subject, message } });
      toast({ title: "تم إنشاء التذكرة بنجاح" });
      setOpen(false);
      setSubject("");
      setMessage("");
      queryClient.invalidateQueries({ queryKey: getListTicketsQueryKey() });
    } catch (err: any) {
      toast({
        title: "خطأ",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open': return <span className="flex items-center gap-1 text-sm bg-blue-500/10 text-blue-500 px-2 py-1 rounded"><AlertCircle className="w-3 h-3"/> مفتوح</span>;
      case 'in_progress': return <span className="flex items-center gap-1 text-sm bg-amber-500/10 text-amber-500 px-2 py-1 rounded"><Clock className="w-3 h-3"/> قيد المعالجة</span>;
      case 'closed': return <span className="flex items-center gap-1 text-sm bg-primary/10 text-primary px-2 py-1 rounded"><CheckCircle2 className="w-3 h-3"/> مغلق</span>;
      default: return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">الدعم الفني</h1>
          <p className="text-muted-foreground">تذاكر الدعم الخاصة بك</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" /> تذكرة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]" dir="rtl">
            <DialogHeader>
              <DialogTitle>إنشاء تذكرة دعم جديدة</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div>
                <label className="block text-sm font-medium mb-1">الموضوع</label>
                <Input required value={subject} onChange={e => setSubject(e.target.value)} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">الرسالة</label>
                <Textarea required rows={4} value={message} onChange={e => setMessage(e.target.value)} />
              </div>
              <Button type="submit" className="w-full" disabled={createTicket.isPending}>
                {createTicket.isPending ? "جاري الإرسال..." : "إرسال التذكرة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {tickets.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p>لا توجد تذاكر دعم حالياً</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {tickets.map(ticket => (
              <Link key={ticket.id} href={`/support/${ticket.id}`} className="block p-4 hover:bg-secondary/50 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg mb-1">{ticket.subject}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">{ticket.message}</p>
                    <div className="text-xs text-muted-foreground mt-2">
                      تم الإنشاء: {new Date(ticket.createdAt).toLocaleDateString('ar-EG')}
                    </div>
                  </div>
                  <div>
                    {getStatusBadge(ticket.status)}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
