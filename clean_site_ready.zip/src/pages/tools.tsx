import { useState } from "react";
import { useListCategories, useListTools } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Search, Terminal, Activity, Globe, Shield, Zap, Lock, Coins } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

const getIcon = (name: string) => {
  const icons: Record<string, React.ElementType> = {
    Terminal, Activity, Globe, Shield, Zap, Search
  };
  const Icon = icons[name] || Globe;
  return <Icon className="w-5 h-5" />;
};

const toolSlugMap: Record<string, string> = {
  "/tools/ip-lookup": "ip-lookup",
  "/tools/dns-lookup": "dns-lookup",
  "/tools/ping": "ping",
  "/tools/speed-test": "speed-test",
  "/tools/http-headers": "http-headers",
  "/tools/ssl-check": "ssl-check",
  "/tools/password-gen": "password-gen",
  "/tools/json-editor": "json-editor",
  "/tools/whois": "whois",
  "/tools/port-scan": "port-scan",
};

// Premium tools that cost points
const premiumSlugs = new Set(["speed-test", "ssl-check", "whois", "port-scan"]);

export default function Tools() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const { user } = useAuth();

  const { data: categories = [] } = useListCategories();
  const { data: tools = [] } = useListTools({
    search: search || undefined,
    categoryId: selectedCategory
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">الأدوات</h1>
          <p className="text-muted-foreground">تصفح واستخدم جميع الأدوات المتاحة — الأدوات المميزة تحتاج نقاط</p>
        </div>
        <div className="w-full md:w-auto flex flex-col md:flex-row gap-4">
          <div className="relative w-full md:w-64">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              className="w-full pl-4 pr-10 bg-card border-border"
              placeholder="بحث عن أداة..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Points hint */}
      <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 mb-6 flex items-center gap-3">
        <Coins className="w-5 h-5 text-amber-400 shrink-0" />
        <p className="text-sm text-amber-300">
          الأدوات العادية مجانية تماماً. الأدوات المميزة <span className="text-amber-400 font-bold">(🔒)</span> تحتاج 5 نقاط لكل استخدام.
          {!user && <> <Link href="/login" className="underline text-amber-400">سجّل دخولك</Link> وأكمل المهام اليومية لكسب النقاط!</>}
          {user && <> أكمل <Link href="/tasks" className="underline text-amber-400">المهام اليومية</Link> لكسب المزيد من النقاط!</>}
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory(undefined)}
          className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
            selectedCategory === undefined
              ? "bg-primary text-primary-foreground"
              : "bg-card text-muted-foreground hover:text-white border border-border"
          }`}
        >
          الكل
        </button>
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
              selectedCategory === cat.id
                ? "bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground hover:text-white border border-border"
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {tools.map(tool => {
          const slug = tool.url ? toolSlugMap[tool.url] : undefined;
          const isPremium = tool.isPremium || (slug ? premiumSlugs.has(slug) : false);
          const href = slug ? `/tool/${slug}` : (tool.url || "#");
          const isInternal = !!slug;

          return isInternal ? (
            <Link
              key={tool.id}
              href={href}
              className="group bg-card border border-border rounded-xl p-6 hover:border-primary/50 hover:bg-secondary/50 transition-all duration-300 flex flex-col"
            >
              <div className="w-12 h-12 bg-background border border-border rounded-lg flex items-center justify-center text-primary mb-4 group-hover:scale-110 group-hover:bg-primary/10 transition-transform">
                {getIcon(tool.icon)}
              </div>
              <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">{tool.name}</h3>
              <p className="text-muted-foreground text-sm line-clamp-2 flex-1">{tool.description}</p>

              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs bg-secondary px-2 py-1 rounded text-muted-foreground">
                  {tool.categoryName}
                </span>
                {isPremium ? (
                  <span className="text-xs bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-1 rounded flex items-center gap-1">
                    <Lock className="w-3 h-3" /> 5 نقاط
                  </span>
                ) : (
                  <span className="text-xs bg-primary/10 text-primary border border-primary/20 px-2 py-1 rounded">
                    مجاني
                  </span>
                )}
              </div>
            </Link>
          ) : (
            <a
              key={tool.id}
              href={href}
              target="_blank"
              rel="noreferrer"
              className="group bg-card border border-border rounded-xl p-6 hover:border-primary/50 hover:bg-secondary/50 transition-all duration-300 flex flex-col"
            >
              <div className="w-12 h-12 bg-background border border-border rounded-lg flex items-center justify-center text-primary mb-4 group-hover:scale-110 group-hover:bg-primary/10 transition-transform">
                {getIcon(tool.icon)}
              </div>
              <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">{tool.name}</h3>
              <p className="text-muted-foreground text-sm line-clamp-2 flex-1">{tool.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs bg-secondary px-2 py-1 rounded text-muted-foreground">
                  {tool.categoryName}
                </span>
                {isPremium && (
                  <span className="text-xs bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-1 rounded flex items-center gap-1">
                    <Zap className="w-3 h-3" /> برو
                  </span>
                )}
              </div>
            </a>
          );
        })}
        {tools.length === 0 && (
          <div className="col-span-full text-center py-12 text-muted-foreground bg-card rounded-xl border border-border">
            لم يتم العثور على أدوات
          </div>
        )}
      </div>
    </div>
  );
}
