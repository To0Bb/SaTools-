import { useListPlans } from "@workspace/api-client-react";
import { Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Plans() {
  const { data: plans = [] } = useListPlans();

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-4">خطط الاشتراك</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          اختر الخطة المناسبة لاحتياجاتك واستفد من جميع ميزات منصة SaTools
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map(plan => (
          <div 
            key={plan.id}
            className={`relative flex flex-col bg-card rounded-2xl border ${
              plan.isPopular ? 'border-primary shadow-lg shadow-primary/10' : 'border-border'
            } p-8`}
          >
            {plan.isPopular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1">
                <Star className="w-4 h-4 fill-current" /> الأكثر شعبية
              </div>
            )}
            
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-black text-white">${plan.price}</span>
                <span className="text-muted-foreground">
                  /{plan.period === 'monthly' ? 'شهرياً' : plan.period === 'yearly' ? 'سنوياً' : 'مدى الحياة'}
                </span>
              </div>
            </div>

            <ul className="space-y-4 mb-8 flex-1">
              {plan.features.map((feature, i) => (
                <li key={i} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-foreground/90">{feature}</span>
                </li>
              ))}
            </ul>

            <Button 
              className="w-full mt-auto"
              variant={plan.isPopular ? 'default' : 'outline'}
              size="lg"
            >
              اشترك الآن
            </Button>
          </div>
        ))}
        {plans.length === 0 && (
          <div className="col-span-full text-center py-12 text-muted-foreground bg-card rounded-xl border border-border">
            جاري تحميل الخطط...
          </div>
        )}
      </div>
    </div>
  );
}
