import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useLogout, useGetPointsBalance } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetMeQueryKey } from "@workspace/api-client-react";
import { Shield, LogOut, User as UserIcon, Coins } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const logout = useLogout();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: balance } = useGetPointsBalance({ query: { enabled: !!user } });

  const handleLogout = async () => {
    await logout.mutateAsync(undefined);
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    setLocation("/");
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground font-sans flex flex-col">
      <header className="border-b border-border bg-card p-4 sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="font-bold text-xl flex items-center gap-2 hover:opacity-80 transition-opacity">
            <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-sm font-black">HOST</span>
            <span className="text-white tracking-wider">SaTools</span>
          </Link>

          <nav className="hidden md:flex gap-6 font-medium">
            <Link href="/tools" className="text-muted-foreground hover:text-white transition-colors">الأدوات</Link>
            <Link href="/chat" className="text-muted-foreground hover:text-white transition-colors">الشات</Link>
            <Link href="/support" className="text-muted-foreground hover:text-white transition-colors">الدعم</Link>
            <Link href="/tasks" className="text-muted-foreground hover:text-white transition-colors">المهام</Link>
            <Link href="/phone-numbers" className="text-muted-foreground hover:text-white transition-colors">الأرقام الدولية</Link>
            <Link href="/file-creator" className="text-muted-foreground hover:text-white transition-colors">منشئ الملفات</Link>
            {user?.role === 'admin' && (
              <Link href="/admin" className="text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
                <Shield className="w-4 h-4" /> الإدارة
              </Link>
            )}
          </nav>

          <div className="flex gap-3 items-center">
            {user ? (
              <>
                {/* Points Badge */}
                <Link href="/tasks" className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 px-3 py-1.5 rounded-lg text-sm hover:bg-amber-500/20 transition-colors">
                  <Coins className="w-4 h-4" />
                  <span className="font-bold">{balance?.balance ?? (user as any).points ?? 0}</span>
                </Link>
                <div className="flex items-center gap-2 text-sm">
                  <UserIcon className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium text-white">{user.displayName || user.username}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 bg-secondary text-secondary-foreground rounded text-sm hover:bg-secondary/80 flex items-center gap-1 transition-colors"
                >
                  خروج <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="px-4 py-2 bg-secondary text-secondary-foreground rounded text-sm font-medium hover:bg-secondary/80 transition-colors">دخول</Link>
                <Link href="/register" className="px-4 py-2 bg-primary text-primary-foreground rounded text-sm font-medium hover:bg-primary/90 transition-colors">إنشاء حساب</Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-border bg-card mt-auto py-8">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          جميع الحقوق محفوظة &copy; {new Date().getFullYear()} SaTools
        </div>
      </footer>
    </div>
  );
}
